<?php
 class adminlayoutController
 {
 	function __construct()
 	{

 	}
 	public function test()
 	{
 		$context = new DbContext();
 		$userProfile = new user_profile();
 		
 	}
 	
 }
