<?php

/**
* 
*/
class DefaultHelper 
{
	
	function __construct()
	{
		
	}
	function currentUser()
	{
		return $_SESSION['user'];
	}
}