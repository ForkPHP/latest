<?php

// $GLOBALS['DOC'] = array (
//   'domobject' => 
//   array (
//     'properties' => 
//     array (
//       0 => 'class',
//     ),
//     'methods' => 
//     array (
//       '__construct' => 
//       array (
//         'params' => 
//         array (
//         ),
//         'code' => 'CWZ1bmN0aW9uIF9fY29uc3RydWN0KCkKCXsKCgl9Cg==',
//       ),
//       'link' => 
//       array (
//         'params' => 
//         array (
//           0 => 'text',
//           1 => 'url',
//           2 => 'params',
//         ),
//         'code' => 'CWZ1bmN0aW9uIGxpbmsoJHRleHQsJHVybCwkcGFyYW1zPWFycmF5KCkpCgl7CgoJCWlmKCFpc19zdHJpbmcoJHVybCkpCgkJewoJCQlpZihnZXRfY2xhc3MoJHVybCk9PSJNVkMiKQoJCQl7CgkJCQkkdXJsPSIvIi4kR0xPQkFMU1snaG9zdCddLiIvIi4kdXJsLT5tb2R1bGUuIi8iLiR1cmwtPmNvbnRyb2xsZXIuIi8iLiR1cmwtPmFjdGlvbjsKCgkJCX0KCQl9CgkJaWYoY291bnQoJHBhcmFtcyk+MCkKCQl7CgkJCSR1cmwuPSI/IjsKCQkJZm9yZWFjaCAoJHBhcmFtcyBhcyAka2V5ID0+ICR2YWx1ZSkgewoJCQkJJHVybCAuPSRrZXkuIj0iLiR2YWx1ZS4iJiI7CgkJCX0KCQkJJHVybD1zdWJzdHIoJHVybCwgMCxzdHJsZW4oJHVybCktMSk7CgkJCQoJCX0KCQkvL2VjaG8gJHVybDsKCQllY2hvICc8YSBocmVmPScuJHVybC4nPicuJHRleHQuJzwvYT4nOwoJfQo=',
//       ),
//       'table' => 
//       array (
//         'params' => 
//         array (
//           0 => 'data',
//           1 => 'class',
//         ),
//         'code' => 'CWZ1bmN0aW9uIHRhYmxlKCRkYXRhLCRjbGFzcz0iIikKCXsKCQlpZihjb3VudCgkZGF0YSk+MCkKCQl7CgkJCSRzdHJpbmc9Ijx0YWJsZSBjbGFzcz0nIi4kY2xhc3MuIic+XG4iOwoJCQkka2V5cyA9IGFycmF5X2tleXMoJGRhdGFbMF0pOwoJCQkkc3RyaW5nIC49Ijx0cj5cbiI7CgkJCWZvcmVhY2ggKCRrZXlzIGFzICRrZXkpIHsKCQkJCSRzdHJpbmcgLj0iPHRoPiAka2V5IDwvdGg+XG4iOwoJCQl9CgkJCSRzdHJpbmcgLj0iPC90cj5cbiI7CgkJCWZvcmVhY2ggKCRkYXRhIGFzICRyb3cpIHsKCQkJCSRzdHJpbmcgLj0iPHRyPlxuIjsKCQkJCWZvcmVhY2ggKCRyb3cgYXMgJGtleSA9PiAkdmFsdWUpIHsKCQkJCQkkc3RyaW5nIC49ICI8dGQ+ICR2YWx1ZSA8L3RkPlxuIjs7CgkJCQl9CgkJCQkkc3RyaW5nIC49IjwvdHI+XG4iOwoJCQl9CgkJfQoJCWVjaG8gJHN0cmluZzsKCX0K',
//       ),
//     ),
//   ),
//   'mvc' => 
//   array (
//     'properties' => 
//     array (
//       0 => 'module',
//       1 => 'controller',
//       2 => 'action',
//     ),
//     'methods' => 
//     array (
//       '__construct' => 
//       array (
//         'params' => 
//         array (
//           0 => 'mvc',
//         ),
//         'code' => 'CWZ1bmN0aW9uIF9fY29uc3RydWN0KCRtdmM9YXJyYXkoKSkKCXsKCQkkdGhpcy0+bW9kdWxlID0gaXNzZXQoJG12Y1snbW9kdWxlJ10pPyRtdmNbJ21vZHVsZSddOiRHTE9CQUxTWydmb3Jrb2JqJ11bJ21vZHVsZSddOwoJCSR0aGlzLT5jb250cm9sbGVyID0gaXNzZXQoJG12Y1snY29udHJvbGxlciddKT8kbXZjWydjb250cm9sbGVyJ106JEdMT0JBTFNbJ2ZvcmtvYmonXVsnY29udHJvbGxlciddOwoJCSR0aGlzLT5hY3Rpb24gPSBpc3NldCgkbXZjWydhY3Rpb24nXSk/JG12Y1snYWN0aW9uJ106ImluZGV4IjsKCX0K',
//       ),
//     ),
//   ),
//   'sys_config' => 
//   array (
//     'properties' => 
//     array (
//     ),
//     'methods' => 
//     array (
//       'getConnection' => 
//       array (
//         'params' => 
//         array (
//           0 => 'db',
//         ),
//         'code' => 'CXB1YmxpYyBmdW5jdGlvbiBnZXRDb25uZWN0aW9uKCRkYikNCgl7DQoJCSAgJGNvbmZpZyA9cGFyc2VfaW5pX2ZpbGUoJF9TRVJWRVJbJ0RPQ1VNRU5UX1JPT1QnXS4kR0xPQkFMU1snaG9zdCddLiIvQXBwL2FwcGxpY2F0aW9uLmluaSIpOw0KCQkgICRob3N0PSRjb25maWdbIm15c3FsLiIuJGRiLiIuaG9zdCJdOw0KCQkgICR1bmFtZT0kY29uZmlnWyJteXNxbC4iLiRkYi4iLnVzZXJuYW1lIl07DQoJCSAgJHBhc3M9JGNvbmZpZ1sibXlzcWwuIi4kZGIuIi5wYXNzd29yZCJdOw0KCQkgICRkYmFzZT0kY29uZmlnWyJteXNxbC4iLiRkYi4iLmRibmFtZSJdOw0KCQkgIA0KCQkgIHRyeQ0KCQkgIHsNCgkJCSAgICRjb24gPSBuZXcgUERPKCJteXNxbDpob3N0PSRob3N0O2RibmFtZT0kZGJhc2UiLCAkdW5hbWUsICRwYXNzKTsNCgkJCSAgICRjb24tPnNldEF0dHJpYnV0ZShQRE86OkFUVFJfRVJSTU9ERSwgUERPOjpFUlJNT0RFX0VYQ0VQVElPTik7DQoJCSAgfQ0KCQkgIGNhdGNoIChQRE9FeGNlcHRpb24gJGUpIA0KCQkgIHsNCgkJCSAgICBwcmludCAiRXJyb3IhOiAiIC4gJGUtPmdldE1lc3NhZ2UoKSAuICI8YnIvPiI7DQoJCQkgICAgZGllKCk7DQoJCSAgfQ0KCQkgIHJldHVybiAkY29uOw0KCQkgIA0KCX0NCg==',
//       ),
//     ),
//   ),
//   'mysqlconnection' => 
//   array (
//     'properties' => 
//     array (
//       0 => 'db',
//     ),
//     'methods' => 
//     array (
//       '__construct' => 
//       array (
//         'params' => 
//         array (
//           0 => 'db',
//         ),
//         'code' => 'CXB1YmxpYyBmdW5jdGlvbiBfX2NvbnN0cnVjdCgkZGI9Im1haW5kYiIpDQoJew0KCQkkdGhpcy0+ZGI9JGRiOw0KCX0NCg==',
//       ),
//       'fetchAll' => 
//       array (
//         'params' => 
//         array (
//           0 => 'query',
//         ),
//         'code' => 'CXB1YmxpYyBmdW5jdGlvbiBmZXRjaEFsbCgkcXVlcnkpDQoJew0KCQkkZGJPYmogPSBuZXcgc3lzX2NvbmZpZygpOw0KCQkkY29ubmVjdGlvbk9iaiA9ICRkYk9iai0+Z2V0Q29ubmVjdGlvbigkdGhpcy0+ZGIpOw0KCQkkcmVzdWx0ID0gbXlzcWxpX3F1ZXJ5KCRjb25uZWN0aW9uT2JqLCRxdWVyeSk7DQoJCSRkYXRhX2FycmF5ID0gYXJyYXkoKTsNCgkJd2hpbGUgKCRhcnJheSA9IG15c3FsaV9mZXRjaF9hc3NvYygkcmVzdWx0KSkNCgkJew0KCQkJJGRhdGFfYXJyYXlbXSA9ICRhcnJheTsNCgkJfQ0KCQlyZXR1cm4gJGRhdGFfYXJyYXk7DQoJfQ0K',
//       ),
//       'insert' => 
//       array (
//         'params' => 
//         array (
//           0 => 'data',
//         ),
//         'code' => 'CXB1YmxpYyBmdW5jdGlvbiBpbnNlcnQoJGRhdGEpDQoJew0KCQkNCgkJJGRiT2JqID0gbmV3IHN5c19jb25maWcoKTsNCgkJJGNvbm5lY3Rpb25PYmogPSAkZGJPYmotPmdldENvbm5lY3Rpb24oJHRoaXMtPmRiKTsNCgkJJHRhYmxlPSRkYXRhWyd0YWJsZSddOw0KCQkkcHJlcCA9IGFycmF5KCk7DQoJCWZvcmVhY2goJGRhdGFbJ2RhdGEnXSBhcyAkayA9PiAkdiApDQoJCXsNCgkgIAkgICRwcmVwWyc6Jy4ka10gPSAkdjsNCgkJfQ0KCQkkcXVlcnkgPSAkY29ubmVjdGlvbk9iai0+cHJlcGFyZSgiSU5TRVJUIElOVE8gJHRhYmxlICggIiAuIGltcGxvZGUoJywgJyxhcnJheV9rZXlzKCRkYXRhWydkYXRhJ10pKSAuICIpIFZBTFVFUyAoIiAuIGltcGxvZGUoJywgJyxhcnJheV9rZXlzKCRwcmVwKSkgLiAiKSIpOw0KCQkkcXVlcnktPmV4ZWN1dGUoJHByZXApOwkNCgl9DQo=',
//       ),
//       'select' => 
//       array (
//         'params' => 
//         array (
//           0 => 'data',
//         ),
//         'code' => 'CXB1YmxpYyBmdW5jdGlvbiBzZWxlY3QoJGRhdGEpDQoJew0KCQkkZGJPYmogPSBuZXcgc3lzX2NvbmZpZygpOw0KCQkkY29ubmVjdGlvbk9iaiA9ICRkYk9iai0+Z2V0Q29ubmVjdGlvbigkdGhpcy0+ZGIpOw0KCQkkdGFibGU9JGRhdGFbJ3RhYmxlJ107DQoJCSRwcmVwID0gYXJyYXkoKTsNCgkJJHdoZXJlPWFycmF5KCk7DQoJCWZvcmVhY2goJGRhdGFbJ2NvbmRpdGlvbiddIGFzICRrID0+ICR2ICkNCgkJew0KCSAgCSAgJHByZXBbJzonLiRrXSA9ICR2Ow0KCSAgCSAgJHdoZXJlW10gPSAkay4iPSIuIjoiLiRrOw0KCQl9DQoJCWlmKGNvdW50KCRkYXRhWydjb25kaXRpb24nXSk+MCkNCgkJJHF1ZXJ5ID0gJGNvbm5lY3Rpb25PYmotPnByZXBhcmUoIlNFTEVDVCAqIEZST00gJHRhYmxlIFdIRVJFICIgLiBpbXBsb2RlKCcgQU5EICcsYXJyYXlfdmFsdWVzKCR3aGVyZSkpICk7DQoJCWVsc2UNCgkJJHF1ZXJ5ID0gJGNvbm5lY3Rpb25PYmotPnByZXBhcmUoIlNFTEVDVCAqIEZST00gJHRhYmxlICIgKTsNCgkJJHF1ZXJ5LT5leGVjdXRlKCRwcmVwKTsNCgkJJHJlcz0kcXVlcnktPmZldGNoQWxsKFBETzo6RkVUQ0hfQVNTT0MpOw0KDQoJCXJldHVybiAkcmVzOw0KCX0NCg==',
//       ),
//       'delete' => 
//       array (
//         'params' => 
//         array (
//           0 => 'data',
//         ),
//         'code' => 'CXB1YmxpYyBmdW5jdGlvbiBkZWxldGUoJGRhdGEpDQoJew0KCQkkZGJPYmogPSBuZXcgc3lzX2NvbmZpZygpOw0KCQkkY29ubmVjdGlvbk9iaiA9ICRkYk9iai0+Z2V0Q29ubmVjdGlvbigkdGhpcy0+ZGIpOw0KCQkkdGFibGU9JGRhdGFbJ3RhYmxlJ107DQoJCSR3aGVyZT1hcnJheSgpOw0KCQlmb3JlYWNoKCRkYXRhWydjb25kaXRpb24nXSBhcyAkayA9PiAkdiApDQoJCXsNCgkgIAkgICRwcmVwWyc6Jy4ka10gPSAkdjsNCgkgIAkgICR3aGVyZVtdID0gJGsuIj0iLiI6Ii4kazsNCgkJfQ0KCQkkcXVlcnkgPSAkY29ubmVjdGlvbk9iai0+cHJlcGFyZSgiU0VMRUNUICogRlJPTSAkdGFibGUgV0hFUkUgIiAuIGltcGxvZGUoJyBBTkQgJyxhcnJheV92YWx1ZXMoJHdoZXJlKSkgKTsNCgkJJHF1ZXJ5LT5leGVjdXRlKCRwcmVwKTsNCgkJJHJlcz0kcXVlcnktPmZldGNoKFBETzo6RkVUQ0hfQVNTT0MpOw0KCQkkcXVlcnkgPSAkY29ubmVjdGlvbk9iai0+cHJlcGFyZSgiREVMRVRFIEZST00gJHRhYmxlIFdIRVJFICIgLiBpbXBsb2RlKCcgQU5EICcsYXJyYXlfdmFsdWVzKCR3aGVyZSkpICk7DQoJCSRxdWVyeS0+ZXhlY3V0ZSgkcHJlcCk7CQ0KCQlyZXR1cm4gJHJlczsNCgl9DQo=',
//       ),
//       'update' => 
//       array (
//         'params' => 
//         array (
//           0 => 'udata',
//         ),
//         'code' => 'CXB1YmxpYyBmdW5jdGlvbiB1cGRhdGUoJHVkYXRhKQ0KCXsNCgkJJGRiT2JqID0gbmV3IHN5c19jb25maWcoKTsNCgkJJGNvbm5lY3Rpb25PYmogPSAkZGJPYmotPmdldENvbm5lY3Rpb24oJHRoaXMtPmRiKTsNCgkJJHRhYmxlPSR1ZGF0YVsndGFibGUnXTsNCgkJJGNvbmQ9YXJyYXkoKTsNCgkJJGRhdGE9YXJyYXkoKTsNCgkJZm9yZWFjaCgkdWRhdGFbJ2RhdGEnXSBhcyAkayA9PiAkdiApDQoJCXsNCgkgIAkgICRwcmVwWyc6ZGF0YScuJGtdID0gJHY7DQoJICAJICAkZGF0YVtdID0gJGsuIj0iLiI6ZGF0YSIuJGs7DQoJCX0NCgkJZm9yZWFjaCgkdWRhdGFbJ2NvbmRpdGlvbiddIGFzICRrID0+ICR2ICkNCgkJew0KCSAgCSAgJHByZXBbJzpjb25kJy4ka10gPSAkdjsNCgkgIAkgICRjb25kW10gPSAkay4iPSIuIjpjb25kIi4kazsNCgkJfQ0KCQkkcXVlcnkgPSAkY29ubmVjdGlvbk9iai0+cHJlcGFyZSgiVVBEQVRFICR0YWJsZSBTRVQgIiAuIGltcGxvZGUoJywnLGFycmF5X3ZhbHVlcygkZGF0YSkpLiIgV0hFUkUgIi5pbXBsb2RlKCcgQU5EICcsIGFycmF5X3ZhbHVlcygkY29uZCkpICk7DQoJCXJldHVybiAkcXVlcnktPmV4ZWN1dGUoJHByZXApOwkJDQoJfQ0K',
//       ),
//     ),
//   ),
//   'entityframework' => 
//   array (
//     'properties' => 
//     array (
//       0 => 'table',
//       1 => 'db',
//     ),
//     'methods' => 
//     array (
//       '__construct' => 
//       array (
//         'params' => 
//         array (
//           0 => 'db',
//           1 => 'table',
//         ),
//         'code' => 'CWZ1bmN0aW9uIF9fY29uc3RydWN0KCRkYiwkdGFibGUpCgl7CgkJJHRoaXMtPnRhYmxlPSR0YWJsZTsKCQkkdGhpcy0+ZGI9JGRiOwoJfQo=',
//       ),
//     ),
//   ),
//   'entity' => 
//   array (
//     'properties' => 
//     array (
//       0 => 'class',
//       1 => 'data',
//     ),
//     'methods' => 
//     array (
//       '__construct' => 
//       array (
//         'params' => 
//         array (
//           0 => 'object',
//         ),
//         'code' => 'IGZ1bmN0aW9uIF9fY29uc3RydWN0KCRvYmplY3QpCiB7CiAJaWYoaXNfYXJyYXkoJG9iamVjdCkpCiAJewogCQlpZihjb3VudCgkb2JqZWN0KT4wKQogCQl7CgkgCQkkY2xhc3M9Z2V0X2NsYXNzKCRvYmplY3RbMF0pOwoJIAkJJHRoaXMtPmNsYXNzPSRjbGFzczsKCSAJCSR0aGlzLT5kYXRhPSRvYmplY3Q7CiAJCX0KIAl9CiB9Cg==',
//       ),
//       '__get' => 
//       array (
//         'params' => 
//         array (
//           0 => 'property',
//         ),
//         'code' => 'IHB1YmxpYyBmdW5jdGlvbiBfX2dldCgkcHJvcGVydHkpIHsKICAgIGlmIChwcm9wZXJ0eV9leGlzdHMoJHRoaXMsICRwcm9wZXJ0eSkpIHsKICAgICAgcmV0dXJuICR0aGlzLT4kcHJvcGVydHk7CiAgICB9CiAgfQo=',
//       ),
//       '__set' => 
//       array (
//         'params' => 
//         array (
//           0 => 'property',
//           1 => 'value',
//         ),
//         'code' => 'ICBwdWJsaWMgZnVuY3Rpb24gX19zZXQoJHByb3BlcnR5LCAkdmFsdWUpIHsKICAgIGlmIChwcm9wZXJ0eV9leGlzdHMoJHRoaXMsICRwcm9wZXJ0eSkpIHsKICAgICAgJHRoaXMtPiRwcm9wZXJ0eSA9ICR2YWx1ZTsKICAgIH0KICB9Cg==',
//       ),
//       'where' => 
//       array (
//         'params' => 
//         array (
//           0 => 'cond',
//         ),
//         'code' => 'IGZ1bmN0aW9uIHdoZXJlKCRjb25kKQogewogCQogCSRkYXRhPWFycmF5KCk7CiAJZm9yZWFjaCAoJHRoaXMtPmRhdGEgYXMgJG9iaikgewogCQkkY29uZGl0aW9uID0gJ2lmKCcuJGNvbmQuJyl7cmV0dXJuIDE7fSc7CiAJCSRjb25kaXRpb24gPSBldmFsKCRjb25kaXRpb24pOwogCQlpZigkY29uZGl0aW9uKQogCQl7CiAJCQkkZGF0YVtdPSRvYmo7CiAJCX0KIAl9CiAJJGVudGl0eU9iaj0gbmV3IEVudGl0eSgkZGF0YSk7CiAJcmV0dXJuICRlbnRpdHlPYmo7CiB9Cg==',
//       ),
//       'toObject' => 
//       array (
//         'params' => 
//         array (
//         ),
//         'code' => 'IGZ1bmN0aW9uIHRvT2JqZWN0KCkKIHsKIAkkZGF0YSA9IGFycmF5KCk7CiAJaWYoY291bnQoJHRoaXMtPmRhdGEpPjApCiAJewoJIAlmb3JlYWNoICgkdGhpcy0+ZGF0YSBhcyAkcm93KSB7CgkgCQkkZGF0YVtdPSRyb3c7CgkgCX0KCSAJaWYoY291bnQoJGRhdGEpPT0xKQoJIAl7CgkgCQkkZGF0YT0gJGRhdGFbMF07CgkgCX0KIAl9CiAJcmV0dXJuICRkYXRhOwogfQo=',
//       ),
//       'toArray' => 
//       array (
//         'params' => 
//         array (
//         ),
//         'code' => 'IGZ1bmN0aW9uIHRvQXJyYXkoKQogewogCSRkYXRhID0gYXJyYXkoKTsKIAlpZihjb3VudCgkdGhpcy0+ZGF0YSk+MCkKIAl7CgkgCWZvcmVhY2ggKCR0aGlzLT5kYXRhIGFzICRyb3cpIHsKCSAJCSRjbGFzcyA9ICR0aGlzLT5jbGFzczsKCQkJJHJlZmxlY3Rpb24gPSBuZXcgUmVmbGVjdGlvbkNsYXNzKCRjbGFzcyk7CgkJCSRvYmpSb3c9YXJyYXkoKTsKCQkJZm9yZWFjaCggJHJlZmxlY3Rpb24gLT4gZ2V0UHJvcGVydGllcyhSZWZsZWN0aW9uUHJvcGVydHk6OklTX1BSSVZBVEUpIGFzICRmaWVsZCApCgkJCXsKCQkJICAgICRmaWVsZF9uYW1lID0gJGZpZWxkLT5uYW1lOwoJCQkgICAgJGZpZWxkX3ZhbD0kcm93LT4kZmllbGRfbmFtZTsKCQkJICAvLyAgaWYoIWVtcHR5KCRyb3ctPiRmaWVsZF9uYW1lKSkKCQkJICAgIHsKCQkJICAgIAkkb2JqUm93WyRmaWVsZF9uYW1lXT0kZmllbGRfdmFsOwoJCQkgICAgfQoJCQl9CgkgCQkkZGF0YVtdPSRvYmpSb3c7CgkgCX0KIAl9CiAJaWYoY291bnQoJGRhdGEpPT0xKQogCXsKIAkJJGRhdGE9JGRhdGFbMF07CiAJfQogCXJldHVybiAkZGF0YTsKIH0K',
//       ),
//     ),
//   ),
//   'dbcontext' => 
//   array (
//     'properties' => 
//     array (
//     ),
//     'methods' => 
//     array (
//       'Add' => 
//       array (
//         'params' => 
//         array (
//           0 => 'object',
//         ),
//         'code' => 'CWZ1bmN0aW9uIEFkZCgkb2JqZWN0KQoJewoJCSRyZWZsZWN0aW9uID0gbmV3IFJlZmxlY3Rpb25DbGFzcyhnZXRfY2xhc3MoJG9iamVjdCkpOwoJCSRkYXRhPWFycmF5KCk7CgkJZm9yZWFjaCggJHJlZmxlY3Rpb24gLT4gZ2V0UHJvcGVydGllcyhSZWZsZWN0aW9uUHJvcGVydHk6OklTX1BSSVZBVEUpIGFzICRmaWVsZCApCgkJewoJCSAgICAkZmllbGRfbmFtZSA9ICRmaWVsZC0+bmFtZTsKCQkgICAgJGZpZWxkX3ZhbD0kb2JqZWN0LT4kZmllbGRfbmFtZTsKCQkgICAgJGRhdGFbJGZpZWxkX25hbWVdPSRmaWVsZF92YWw7CgkJfQoJCSRyb3dEYXRhPSBhcnJheSgidGFibGUiPT5nZXRfY2xhc3MoJG9iamVjdCksImRhdGEiPT4kZGF0YSk7CgkJJGNvbiA9IG5ldyBNeXNxbENvbm5lY3Rpb24oJG9iamVjdC0+ZGIpOwoJCSRjb24tPmluc2VydCgkcm93RGF0YSk7CQoJfQo=',
//       ),
//       'Get' => 
//       array (
//         'params' => 
//         array (
//           0 => 'object',
//         ),
//         'code' => 'CWZ1bmN0aW9uIEdldCgkb2JqZWN0KQoJewoJCSRjbGFzcyA9IGdldF9jbGFzcygkb2JqZWN0KTsKCQkkcmVmbGVjdGlvbiA9IG5ldyBSZWZsZWN0aW9uQ2xhc3MoJGNsYXNzKTsKCQkkZGF0YT1hcnJheSgpOwoJCWZvcmVhY2goICRyZWZsZWN0aW9uIC0+IGdldFByb3BlcnRpZXMoUmVmbGVjdGlvblByb3BlcnR5OjpJU19QUklWQVRFKSBhcyAkZmllbGQgKQoJCXsKCQkgICAgJGZpZWxkX25hbWUgPSAkZmllbGQtPm5hbWU7CgkJICAgICRmaWVsZF92YWw9JG9iamVjdC0+JGZpZWxkX25hbWU7CgkJICAgIC8vZWNobyAkZmllbGRfbmFtZS4iXyIuJGZpZWxkX3ZhbC4iXyIuJG9iamVjdC0+JGZpZWxkX25hbWUuIjxicj4iOwoJCSAgICBpZihpc3NldCgkZmllbGRfdmFsKSkKCQkgICAgewoJCSAgICAJJGRhdGFbJGZpZWxkX25hbWVdPSRmaWVsZF92YWw7CgkJICAgIH0KCQl9CgkJJHJvd0RhdGE9IGFycmF5KCJ0YWJsZSI9PiRjbGFzcywiY29uZGl0aW9uIj0+JGRhdGEpOwoJCQoJCSRjb24gPSBuZXcgTXlzcWxDb25uZWN0aW9uKCRvYmplY3QtPmRiKTsKCQkKCQkkZGF0YT0kY29uLT5zZWxlY3QoJHJvd0RhdGEpOwoJCQkKCQkJJG9iakFycmF5PWFycmF5KCk7CgkJCWZvcmVhY2ggKCRkYXRhIGFzICR2YXIpIHsKCQkJCSRvYmogPSBuZXcgJGNsYXNzKCk7CgkJCQlmb3JlYWNoKCAkcmVmbGVjdGlvbiAtPiBnZXRQcm9wZXJ0aWVzKFJlZmxlY3Rpb25Qcm9wZXJ0eTo6SVNfUFJJVkFURSkgYXMgJGZpZWxkICkKCQkJCXsKCQkJCSAgICAkZmllbGRfbmFtZSA9ICRmaWVsZC0+bmFtZTsKCQkJCSAgICAkb2JqLT4kZmllbGRfbmFtZT0kdmFyWyRmaWVsZF9uYW1lXTsKCQkJCX0KCQkJCSRvYmpBcnJheVtdPSRvYmo7CgkJCX0KCgkJCSRlbnRpdHlPYmo9bmV3IEVudGl0eSgkb2JqQXJyYXkpOwoJCQlyZXR1cm4gJGVudGl0eU9iajsKCQkKCQkKCX0K',
//       ),
//       'Delete' => 
//       array (
//         'params' => 
//         array (
//           0 => 'object',
//         ),
//         'code' => 'CWZ1bmN0aW9uIERlbGV0ZSgkb2JqZWN0KQoJewoJCSRjbGFzcyA9IGdldF9jbGFzcygkb2JqZWN0KTsKCQkkcmVmbGVjdGlvbiA9IG5ldyBSZWZsZWN0aW9uQ2xhc3MoJGNsYXNzKTsKCQkkZGF0YT1hcnJheSgpOwoJCSRjb24gPSBuZXcgTXlzcWxDb25uZWN0aW9uKCRvYmplY3QtPmRiKTsKCQlmb3JlYWNoKCAkcmVmbGVjdGlvbiAtPiBnZXRQcm9wZXJ0aWVzKFJlZmxlY3Rpb25Qcm9wZXJ0eTo6SVNfUFJJVkFURSkgYXMgJGZpZWxkICkKCQl7CgkJICAgICRmaWVsZF9uYW1lID0gJGZpZWxkLT5uYW1lOwoJCSAgICAkZmllbGRfdmFsPSRvYmplY3QtPiRmaWVsZF9uYW1lOwoJCSAgICBpZigkb2JqZWN0LT4kZmllbGRfbmFtZSE9IiIpCgkJICAgIHsKCQkgICAgCSRkYXRhWyRmaWVsZF9uYW1lXT0kZmllbGRfdmFsOwoJCSAgICB9CgkJfQoJCSRyb3dEYXRhPSBhcnJheSgidGFibGUiPT4kY2xhc3MsImNvbmRpdGlvbiI9PiRkYXRhKTsKCQkkb2JqID0gbmV3ICRjbGFzcygpOwoJCSRyZXN1bHQgPSAkY29uLT5kZWxldGUoJHJvd0RhdGEpOwoJCWZvcmVhY2goICRyZWZsZWN0aW9uIC0+IGdldFByb3BlcnRpZXMoUmVmbGVjdGlvblByb3BlcnR5OjpJU19QUklWQVRFKSBhcyAkZmllbGQgKQoJCXsKCQkgICAgJGZpZWxkX25hbWUgPSAkZmllbGQtPm5hbWU7CgkJICAgICRvYmotPiRmaWVsZF9uYW1lPSRyZXN1bHRbJGZpZWxkX25hbWVdOwoJCX0KCQlyZXR1cm4gJG9iajsKCX0K',
//       ),
//       'Update' => 
//       array (
//         'params' => 
//         array (
//           0 => 'object',
//         ),
//         'code' => 'CWZ1bmN0aW9uIFVwZGF0ZSgkb2JqZWN0KQoJewoJCSRjbGFzcyA9IGdldF9jbGFzcygkb2JqZWN0KTsKCQkkcmVmbGVjdGlvbiA9IG5ldyBSZWZsZWN0aW9uQ2xhc3MoJGNsYXNzKTsKCQkkZGF0YT1hcnJheSgpOwoJCSRjb24gPSBuZXcgTXlzcWxDb25uZWN0aW9uKCRvYmplY3QtPmRiKTsKCQlmb3JlYWNoKCAkcmVmbGVjdGlvbiAtPiBnZXRQcm9wZXJ0aWVzKFJlZmxlY3Rpb25Qcm9wZXJ0eTo6SVNfUFJJVkFURSkgYXMgJGZpZWxkICkKCQl7CgkJICAgICRmaWVsZF9uYW1lID0gJGZpZWxkLT5uYW1lOwoJCSAgICAkZmllbGRfdmFsPSRvYmplY3QtPiRmaWVsZF9uYW1lOwoJCSAgICBpZigkb2JqZWN0LT4kZmllbGRfbmFtZSE9IiIpCgkJICAgIHsKCQkgICAgCSRkYXRhWyRmaWVsZF9uYW1lXT0kZmllbGRfdmFsOwoJCSAgICB9CgkJfQoJCSRyb3dEYXRhPSBhcnJheSgidGFibGUiPT4kY2xhc3MsImRhdGEiPT4kZGF0YSwiY29uZGl0aW9uIj0+YXJyYXkoImlkIj0+JG9iamVjdC0+aWQpKTsKCQkkY29uLT51cGRhdGUoJHJvd0RhdGEpOwoJCQoJfQo=',
//       ),
//     ),
//   ),
//   'fork_lib' => 
//   array (
//     'properties' => 
//     array (
//       0 => 'module',
//       1 => 'controller',
//       2 => 'action',
//     ),
//     'methods' => 
//     array (
//       '__construct' => 
//       array (
//         'params' => 
//         array (
//         ),
//         'code' => 'CXB1YmxpYyBmdW5jdGlvbiBfX2NvbnN0cnVjdCgpCgl7CgkJJHRoaXMtPm1vZHVsZT0kR0xPQkFMU1snZm9ya29iaiddWydtb2R1bGUnXTsKCQkkdGhpcy0+Y29udHJvbGxlcj0kR0xPQkFMU1snZm9ya29iaiddWydjb250cm9sbGVyJ107CgkJJHRoaXMtPmFjdGlvbj0kR0xPQkFMU1snZm9ya29iaiddWydhY3Rpb24nXTsKCX0K',
//       ),
//       'getModuleName' => 
//       array (
//         'params' => 
//         array (
//         ),
//         'code' => 'CXB1YmxpYyBmdW5jdGlvbiBnZXRNb2R1bGVOYW1lKCkKCXsKCQlyZXR1cm4gJHRoaXMtPm1vZHVsZTsKCX0K',
//       ),
//       'getControllerName' => 
//       array (
//         'params' => 
//         array (
//         ),
//         'code' => 'CXB1YmxpYyBmdW5jdGlvbiBnZXRDb250cm9sbGVyTmFtZSgpCgl7CgkJcmV0dXJuICR0aGlzLT5jb250cm9sbGVyOwoJfQo=',
//       ),
//       'getActionName' => 
//       array (
//         'params' => 
//         array (
//         ),
//         'code' => 'CXB1YmxpYyBmdW5jdGlvbiBnZXRBY3Rpb25OYW1lKCkKCXsKCQlyZXR1cm4gJHRoaXMtPmFjdGlvbjsKCX0K',
//       ),
//       'Session' => 
//       array (
//         'params' => 
//         array (
//         ),
//         'code' => 'CXB1YmxpYyBmdW5jdGlvbiBTZXNzaW9uKCkKCXsKCQkKCX0K',
//       ),
//       'getFileContent' => 
//       array (
//         'params' => 
//         array (
//           0 => 'file',
//         ),
//         'code' => 'CXB1YmxpYyBmdW5jdGlvbiBnZXRGaWxlQ29udGVudCgkZmlsZSkKCXsKCQl0cnkKCQl7CgkJCXJldHVybiBmaWxlX2dldF9jb250ZW50cygkZmlsZSk7CgkJCQoJCX0KCQljYXRjaChFeGNlcHRpb24gJGUpCgkJewoJCQlyZXR1cm4gJGUtPmdldE1lc3NhZ2UoKTsKCQl9Cgl9Cg==',
//       ),
//       'updateFileContent' => 
//       array (
//         'params' => 
//         array (
//           0 => 'file',
//           1 => 'content',
//         ),
//         'code' => 'CXB1YmxpYyBmdW5jdGlvbiB1cGRhdGVGaWxlQ29udGVudCgkZmlsZSwkY29udGVudCkKCXsKCQl0cnkKCQl7CgkJCWZpbGVfcHV0X2NvbnRlbnRzKCRmaWxlLCAkY29udGVudCk7CgkJCXJldHVybiAxOwoJCX0KCQljYXRjaChFeGNlcHRpb24gJGUpCgkJewoJCQlyZXR1cm4gJGUtPmdldE1lc3NhZ2UoKTsKCQl9Cgl9Cg==',
//       ),
//       'isFileExists' => 
//       array (
//         'params' => 
//         array (
//           0 => 'file',
//         ),
//         'code' => 'CXB1YmxpYyBmdW5jdGlvbiBpc0ZpbGVFeGlzdHMoJGZpbGUpCgl7CgkJcmV0dXJuIGlzX2ZpbGUoJGZpbGUpOwoJfQo=',
//       ),
//       'isFolderExists' => 
//       array (
//         'params' => 
//         array (
//           0 => 'file',
//         ),
//         'code' => 'CXB1YmxpYyBmdW5jdGlvbiBpc0ZvbGRlckV4aXN0cygkZmlsZSkKCXsKCQlyZXR1cm4gaXNfZGlyKCRmaWxlKTsKCX0K',
//       ),
//       'createFile' => 
//       array (
//         'params' => 
//         array (
//           0 => 'folder',
//           1 => 'file',
//         ),
//         'code' => 'CXB1YmxpYyBmdW5jdGlvbiBjcmVhdGVGaWxlKCRmb2xkZXIsJGZpbGUpCgl7CgkJdHJ5CgkJewoJCQkgICRmaWxlID0gZm9wZW4oJGZvbGRlci4iLyIuJGZpbGUsInciKTsKCQkJICByZXR1cm4gdHJ1ZTsKCQl9CgkJY2F0Y2goRXhjZXB0aW9uICRlKQoJCXsKCQkJcmV0dXJuICRlLT5nZXRNZXNzYWdlKCk7CgkJfQoJfQo=',
//       ),
//       'createFolder' => 
//       array (
//         'params' => 
//         array (
//           0 => 'folder',
//           1 => 'file',
//         ),
//         'code' => 'CXB1YmxpYyBmdW5jdGlvbiBjcmVhdGVGb2xkZXIoJGZvbGRlciwkZmlsZSkKCXsKCQl0cnkKCQl7CgkJCSAgJGZpbGUgPSBta2RpcigkZm9sZGVyLiIvIi4kZmlsZSk7CgkJCSAgcmV0dXJuIHRydWU7CgkJfQoJCWNhdGNoKEV4Y2VwdGlvbiAkZSkKCQl7CgkJCXJldHVybiAkZS0+Z2V0TWVzc2FnZSgpOwoJCX0KCX0K',
//       ),
//       'deleteFolder' => 
//       array (
//         'params' => 
//         array (
//           0 => 'folder',
//         ),
//         'code' => 'CXB1YmxpYyBmdW5jdGlvbiBkZWxldGVGb2xkZXIoJGZvbGRlcikKCXsKCQl0cnkKCQl7CgkJCSAgJGZpbGUgPSAkdGhpcy0+ZGVsZXRlRGlyKCRmb2xkZXIpOwoJCQkgIHJldHVybiB0cnVlOwoJCX0KCQljYXRjaChFeGNlcHRpb24gJGUpCgkJewoJCQlyZXR1cm4gJGUtPmdldE1lc3NhZ2UoKTsKCQl9Cgl9Cg==',
//       ),
//       'deleteDir' => 
//       array (
//         'params' => 
//         array (
//           0 => 'dir',
//         ),
//         'code' => 'CXB1YmxpYyBmdW5jdGlvbiBkZWxldGVEaXIoJGRpcikgCgl7CgkJCgkgICAkaXRlcmF0b3IgPSBuZXcgUmVjdXJzaXZlRGlyZWN0b3J5SXRlcmF0b3IoJGRpcik7CgkgICBmb3JlYWNoIChuZXcgUmVjdXJzaXZlSXRlcmF0b3JJdGVyYXRvcigkaXRlcmF0b3IsIFJlY3Vyc2l2ZUl0ZXJhdG9ySXRlcmF0b3I6OkNISUxEX0ZJUlNUKSBhcyAkZmlsZSkgCgkgICB7CgkgICAgICBpZiAoJGZpbGUtPmlzRGlyKCkpIHsKCSAgICAgICAgIEBybWRpcigkZmlsZS0+Z2V0UGF0aG5hbWUoKSk7CgkgICAgICB9IGVsc2UgewoJICAgICAgICAgQHVubGluaygkZmlsZS0+Z2V0UGF0aG5hbWUoKSk7CgkgICAgICB9CgkgICB9CgkgICBybWRpcigkZGlyKTsKCX0K',
//       ),
//     ),
//   ),
//   'modulemanager' => 
//   array (
//     'properties' => 
//     array (
//       0 => 'module',
//     ),
//     'methods' => 
//     array (
//       '__construct' => 
//       array (
//         'params' => 
//         array (
//           0 => 'module',
//         ),
//         'code' => 'CXB1YmxpYyBmdW5jdGlvbiBfX2NvbnN0cnVjdCgkbW9kdWxlPSIiKQoJewoJCWlmKCRtb2R1bGU9PSIiKSByZXR1cm47CgkJJHRoaXMtPm1vZHVsZT0kbW9kdWxlOwoJCSRkaXJlY3RvcnkgPSAkX1NFUlZFUlsnRE9DVU1FTlRfUk9PVCddLiIvIi4kR0xPQkFMU1snaG9zdCddLiIvbW9kdWxlcy8iLiRtb2R1bGUuIi9jb250cm9sbGVycy8iOwoJCSBmb3JlYWNoKGdsb2IoJGRpcmVjdG9yeSAuICIqLnBocCIpIGFzICRjbGFzcykKCQkgewoJCSAgICAgaW5jbHVkZV9vbmNlICRjbGFzczsKCQkgfQoJfQo=',
//       ),
//       'getAllModules' => 
//       array (
//         'params' => 
//         array (
//         ),
//         'code' => 'CXB1YmxpYyBmdW5jdGlvbiBnZXRBbGxNb2R1bGVzKCkKCXsKCQkkcGF0aCA9ICRfU0VSVkVSWydET0NVTUVOVF9ST09UJ10uIi8iLiRHTE9CQUxTWydob3N0J10uIi9tb2R1bGVzLyI7CgkJJHJlc3VsdHMgPSBzY2FuZGlyKCRwYXRoKTsKCQkkbW9kdWxlcz1hcnJheSgpOwoJCWZvcmVhY2ggKCRyZXN1bHRzIGFzICRyZXN1bHQpIHsKCQkgICAgaWYgKCRyZXN1bHQgPT09ICcuJyBvciAkcmVzdWx0ID09PSAnLi4nIG9yICRyZXN1bHQ9PSJtb2RlbHMiKSBjb250aW51ZTsKCgkJICAgIGlmIChpc19kaXIoJHBhdGggLiAnLycgLiAkcmVzdWx0KSkgewoJCSAgICAgICAgJG1vZHVsZXNbXT0kcmVzdWx0OwoJCSAgICB9CgkJfQoJCXJldHVybiAkbW9kdWxlczsKCX0K',
//       ),
//       'getModuleContollers' => 
//       array (
//         'params' => 
//         array (
//         ),
//         'code' => 'CXB1YmxpYyBmdW5jdGlvbiBnZXRNb2R1bGVDb250b2xsZXJzKCkKCXsKCQlpZihpc19kaXIoJF9TRVJWRVJbJ0RPQ1VNRU5UX1JPT1QnXS4iLyIuJEdMT0JBTFNbJ2hvc3QnXS4iL21vZHVsZXMvIi4kdGhpcy0+bW9kdWxlLiIvY29udHJvbGxlcnMvIikpCgkJewoJCQkkcGF0aCA9ICRfU0VSVkVSWydET0NVTUVOVF9ST09UJ10uIi8iLiRHTE9CQUxTWydob3N0J10uIi9tb2R1bGVzLyIuJHRoaXMtPm1vZHVsZS4iL2NvbnRyb2xsZXJzLyI7CgkJCSRyZXN1bHRzID0gc2NhbmRpcigkcGF0aCk7CgkJCSRjb250cm9sbGVycyA9IGFycmF5KCk7CgkJCWZvcmVhY2ggKCRyZXN1bHRzIGFzICRyZXN1bHQpCgkJCXsKCQkJCWlmKGlzX2ZpbGUoJHBhdGggLiAnLycgLiAkcmVzdWx0KSkKCQkJCXsKCQkJCQkkY29udHJvbGxlcnNbc3RyX3JlcGxhY2UoIi5waHAiLCAiIiwgJHJlc3VsdCldID0gYXJyYXlfZGlmZihnZXRfY2xhc3NfbWV0aG9kcygkdGhpcy0+bW9kdWxlLiJfIi5zdHJfcmVwbGFjZSgiLnBocCIsICIiLCAkcmVzdWx0KSksIGdldF9jbGFzc19tZXRob2RzKCdDb250cm9sbGVyJykpOwoJCQkJfQoJCQl9CgkJCXJldHVybiAkY29udHJvbGxlcnM7CgkJfQoJCWVsc2UKCQl7CgkJCXJldHVybiAtMTsKCQl9CgoJfQo=',
//       ),
//       'getContollerActions' => 
//       array (
//         'params' => 
//         array (
//           0 => 'module',
//           1 => 'controller',
//         ),
//         'code' => 'CXB1YmxpYyBmdW5jdGlvbiBnZXRDb250b2xsZXJBY3Rpb25zKCRtb2R1bGUsJGNvbnRyb2xsZXIpCgl7CgkJaWYoY2xhc3NfZXhpc3RzKCRtb2R1bGUuIl8iLiRjb250cm9sbGVyKSkKCQl7CgkJCXJldHVybiBhcnJheV9kaWZmKEBnZXRfY2xhc3NfbWV0aG9kcygkbW9kdWxlLiJfIi4kY29udHJvbGxlciksIGdldF9jbGFzc19tZXRob2RzKCdDb250cm9sbGVyJykpOwoJCX0KCQllbHNlCgkJewoJCQlyZXR1cm4gLTE7CgkJfQoJfQo=',
//       ),
//       'createModule' => 
//       array (
//         'params' => 
//         array (
//           0 => 'module',
//           1 => 'isLayout',
//           2 => 'isView',
//         ),
//         'code' => 'CXB1YmxpYyBmdW5jdGlvbiBjcmVhdGVNb2R1bGUoJG1vZHVsZSwkaXNMYXlvdXQsJGlzVmlldykKCXsKCQkKCQl0cnkKCQl7CgkJCSRwYXRoID0gJF9TRVJWRVJbJ0RPQ1VNRU5UX1JPT1QnXS4iLyIuJEdMT0JBTFNbJ2hvc3QnXS4iL21vZHVsZXMvIi4kbW9kdWxlLiIvIjsKCQkJaWYoIWlzX2RpcigkcGF0aCkpCgkJCXsKCQkJCW1rZGlyKCRwYXRoKTsKCQkJfQoJCQllbHNlCgkJCXsKCQkJCXJldHVybiAiTW9kdWxlIGFscmVhZHkgZXhpc3RzLiI7CgkJCX0KCQkJaWYoIWlzX2RpcigkcGF0aC4iL2NvbnRyb2xsZXJzLyIpKQoJCQl7CgkJCQlta2RpcigkcGF0aC4iL2NvbnRyb2xsZXJzLyIpOwoJCQkJJGNvbnRlbnQgPSBmaWxlX2dldF9jb250ZW50cygkX1NFUlZFUlsnRE9DVU1FTlRfUk9PVCddLiIvIi4kR0xPQkFMU1snaG9zdCddLiIvbGliL3RlbXBsYXRlcy9jb250cm9sbGVyIik7CgkJCQlpZighaXNfZmlsZSgkcGF0aC4iL2NvbnRyb2xsZXJzL2luZGV4Q29udHJvbGxlci5waHAiKSkKCQkJCXsKCQkJCQkgJGZpbGUgPSBmb3BlbigkcGF0aC4iL2NvbnRyb2xsZXJzL2luZGV4Q29udHJvbGxlci5waHAiLCJ3Iik7CgkJCQkJICRjb2RlPSIiOwoJCQkJCSBpZigkaXNWaWV3PT0iZmFsc2UiKQoJCQkJCSB7CgkJCQkJIAkkY29kZSAuPSckdGhpcy0+dmlld1JlcXVpcmVkPWZhbHNlOycuIlxuXHRcdCI7CgkJCQkJIH0KCQkJCQkgaWYoJGlzTGF5b3V0PT0iZmFsc2UiKQoJCQkJCSB7CgkJCQkJIAkkY29kZSAuPSckdGhpcy0+bGF5b3V0UmVxdWlyZWQ9ZmFsc2U7Jy4iXG5cdFx0IjsKCQkJCQkgfQoJCQkJCSBmaWxlX3B1dF9jb250ZW50cygkcGF0aC4iL2NvbnRyb2xsZXJzL2luZGV4Q29udHJvbGxlci5waHAiLHN0cl9yZXBsYWNlKCJ7e2NvZGV9fSIsICRjb2RlLCBzdHJfcmVwbGFjZSgie3tjb250cm9sbGVybmFtZX19IiwgJG1vZHVsZS4iX2luZGV4Q29udHJvbGxlciIsICRjb250ZW50KSkgKTsKCQkJCX0KCQkJfQoJCQlpZighaXNfZGlyKCRwYXRoLiIvdmlld3MvIikpCgkJCXsKCQkJCW1rZGlyKCRwYXRoLiIvdmlld3MvIik7CgkJCQlpZighaXNfZGlyKCRwYXRoLiIvdmlld3MvaW5kZXgvIikpCgkJCQl7CgkJCQkJbWtkaXIoJHBhdGguIi92aWV3cy9pbmRleC8iKTsKCQkJCQlpZigkaXNWaWV3PT0idHJ1ZSIpCgkJCQkJewoJCQkJCQlpZighaXNfZmlsZSgkcGF0aC4iL3ZpZXdzL2luZGV4L2luZGV4LnBodG1sIikpCgkJCQkJCXsKCQkJCQkJCSRmaWxlID0gZm9wZW4oJHBhdGguIi92aWV3cy9pbmRleC9pbmRleC5waHRtbCIsInciKTsKCQkJCQkJCSRjb250ZW50ID0gZmlsZV9nZXRfY29udGVudHMoJF9TRVJWRVJbJ0RPQ1VNRU5UX1JPT1QnXS4iLyIuJEdMT0JBTFNbJ2hvc3QnXS4iL2xpYi90ZW1wbGF0ZXMvdmlldyIpOwoJCQkJCQkJZmlsZV9wdXRfY29udGVudHMoJHBhdGguIi92aWV3cy9pbmRleC9pbmRleC5waHRtbCIsIHN0cl9yZXBsYWNlKCJ7e2FjdGlvbm5hbWV9fSIsICJpbmRleCIsICRjb250ZW50KSk7CgkJCQkJCX0KCQkJCQl9CgkJCQkJCgkJCQl9CgkJCX0KCQkJaWYoJGlzTGF5b3V0PT0idHJ1ZSIpCgkJCXsKCQkJCWlmKCFpc19maWxlKCRfU0VSVkVSWydET0NVTUVOVF9ST09UJ10uIi8iLiRHTE9CQUxTWydob3N0J10uIi9sYXlvdXRzLyIuJG1vZHVsZS4iLnBodG1sIikpCgkJCQl7CgkJCQkJJGNvbnRlbnQgPSBmaWxlX2dldF9jb250ZW50cygkX1NFUlZFUlsnRE9DVU1FTlRfUk9PVCddLiIvIi4kR0xPQkFMU1snaG9zdCddLiIvbGliL3RlbXBsYXRlcy9sYXlvdXQiKTsKCQkJCQkkZmlsZSA9IGZvcGVuKCRfU0VSVkVSWydET0NVTUVOVF9ST09UJ10uIi8iLiRHTE9CQUxTWydob3N0J10uIi9sYXlvdXRzLyIuJG1vZHVsZS4iLnBodG1sIiwidyIpOwoJCQkJCWZpbGVfcHV0X2NvbnRlbnRzKCRfU0VSVkVSWydET0NVTUVOVF9ST09UJ10uIi8iLiRHTE9CQUxTWydob3N0J10uIi9sYXlvdXRzLyIuJG1vZHVsZS4iLnBodG1sIiwgc3RyX3JlcGxhY2UoInt7bW9kdWxlbmFtZX19IiwgJG1vZHVsZSwgJGNvbnRlbnQpKTsKCQkJCX0KCQkJCSRhcnIgPSBwYXJzZV9pbmlfZmlsZSgkX1NFUlZFUlsnRE9DVU1FTlRfUk9PVCddLiIvIi4kR0xPQkFMU1snaG9zdCddLiIvQXBwL2FwcGxpY2F0aW9uLmluaSIsdHJ1ZSk7CgkJCQkkYXJyWydsYXlvdXRzJ11bJ2xheW91dHMnXVskbW9kdWxlXT0kbW9kdWxlOwoJCQkJJHZhbCA9IHdyaXRlX2luaV9maWxlKCRhcnIsJF9TRVJWRVJbJ0RPQ1VNRU5UX1JPT1QnXS4iLyIuJEdMT0JBTFNbJ2hvc3QnXS4iL0FwcC9hcHBsaWNhdGlvbi5pbmkiLHRydWUpOwoKCQkJfQoJCQlyZXR1cm4gMTsKCQl9CgkJY2F0Y2goRXhjZXB0aW9uICRleHApCgkJewoJCQlyZXR1cm4gJGV4cC0+Z2V0TWVzc2FnZSgpOwoJCX0KCX0K',
//       ),
//       'deleteModule' => 
//       array (
//         'params' => 
//         array (
//           0 => 'module',
//         ),
//         'code' => 'CWZ1bmN0aW9uIGRlbGV0ZU1vZHVsZSgkbW9kdWxlKQoJewoJCSRwYXRoID0gJF9TRVJWRVJbJ0RPQ1VNRU5UX1JPT1QnXS4iLyIuJEdMT0JBTFNbJ2hvc3QnXS4iL21vZHVsZXMvIi4kbW9kdWxlOwoJCSRsaWJPYmogPSBuZXcgRm9ya19MaWIoKTsKCQlpZigkbW9kdWxlICE9IiIpCgkJewoJCQlpZihpc19maWxlKCRfU0VSVkVSWydET0NVTUVOVF9ST09UJ10uIi8iLiRHTE9CQUxTWydob3N0J10uIi9sYXlvdXRzLyIuJG1vZHVsZS4iLnBodG1sIikpCgkJCXsKCQkJCXVubGluaygkX1NFUlZFUlsnRE9DVU1FTlRfUk9PVCddLiIvIi4kR0xPQkFMU1snaG9zdCddLiIvbGF5b3V0cy8iLiRtb2R1bGUuIi5waHRtbCIpOwoJCQl9CgkJCSRsaWJPYmotPmRlbGV0ZURpcigkcGF0aCk7CgkJfQoJCQoJCXJldHVybiAxOwoJfQo=',
//       ),
//       'createController' => 
//       array (
//         'params' => 
//         array (
//           0 => 'module',
//           1 => 'controller',
//           2 => 'isView',
//         ),
//         'code' => 'CWZ1bmN0aW9uIGNyZWF0ZUNvbnRyb2xsZXIoJG1vZHVsZSwkY29udHJvbGxlciwkaXNWaWV3KQoJewoJCSRwYXRoID0gJF9TRVJWRVJbJ0RPQ1VNRU5UX1JPT1QnXS4iLyIuJEdMT0JBTFNbJ2hvc3QnXS4iL21vZHVsZXMvIi4kbW9kdWxlOwoJCXRyeQoJCXsKCQkJJGNvbnRlbnQgPSBmaWxlX2dldF9jb250ZW50cygkX1NFUlZFUlsnRE9DVU1FTlRfUk9PVCddLiIvIi4kR0xPQkFMU1snaG9zdCddLiIvbGliL3RlbXBsYXRlcy9jb250cm9sbGVyIik7CgkJCWlmKCFpc19maWxlKCRwYXRoLiIvY29udHJvbGxlcnMvIi4kY29udHJvbGxlci4iQ29udHJvbGxlci5waHAiKSkKCQkJewoJCQkJICRmaWxlID0gZm9wZW4oJHBhdGguIi9jb250cm9sbGVycy8iLiRjb250cm9sbGVyLiJDb250cm9sbGVyLnBocCIsInciKTsKCQkJCSAkY29kZT0iIjsKCQkJCSBpZigkaXNWaWV3PT0iZmFsc2UiKQoJCQkJIHsKCQkJCSAJJGNvZGUgLj0nJHRoaXMtPnZpZXdSZXF1aXJlZD1mYWxzZTsnLiJcblx0XHQiOwoJCQkJIH0KCQkJCSBmaWxlX3B1dF9jb250ZW50cygkcGF0aC4iL2NvbnRyb2xsZXJzLyIuJGNvbnRyb2xsZXIuIkNvbnRyb2xsZXIucGhwIixzdHJfcmVwbGFjZSgie3tjb2RlfX0iLCAkY29kZSwgc3RyX3JlcGxhY2UoInt7Y29udHJvbGxlcm5hbWV9fSIsICRtb2R1bGUuIl8iLiRjb250cm9sbGVyLiJDb250cm9sbGVyIiwgJGNvbnRlbnQpKSApOwoJCQkJIGlmKCRpc1ZpZXc9PSJ0cnVlIikKCQkJCSB7CgkJCQkgCSRjcmVhdGVWaWV3ID0gJHRoaXMtPmNyZWF0ZVZpZXcoJG1vZHVsZSwkY29udHJvbGxlciwiaW5kZXgiKTsKCQkJCSAJaWYoJGNyZWF0ZVZpZXcgPT0gIi0xIikKCQkJCSAJewoJCQkJIAkJcmV0dXJuICJ2aWV3IGZpbGUgJGFjdGlvbi5waHRtbCBhbHJlYWR5IGV4aXN0cy4iOwoJCQkJIAl9CgkJCQkgfQoJCQl9CgkJCWVsc2UKCQkJewoJCQkJcmV0dXJuICJDb250cm9sbGVyICRjb250cm9sbGVyIGFscmVhZHkgRXhpc3RzLiI7CgkJCX0KCQkJcmV0dXJuIDE7CgkJfQoJCWNhdGNoKEV4Y2VwdGlvbiAkZXhwKQoJCXsKCQkJcmV0dXJuICRleHAtPmdldE1lc3NhZ2UoKTsKCQl9Cgl9Cg==',
//       ),
//       'deleteController' => 
//       array (
//         'params' => 
//         array (
//           0 => 'module',
//           1 => 'controller',
//         ),
//         'code' => 'CXB1YmxpYyBmdW5jdGlvbiBkZWxldGVDb250cm9sbGVyKCRtb2R1bGUsJGNvbnRyb2xsZXIpCgl7CQoJCSRwYXRoID0gJF9TRVJWRVJbJ0RPQ1VNRU5UX1JPT1QnXS4iLyIuJEdMT0JBTFNbJ2hvc3QnXS4iL21vZHVsZXMvIi4kbW9kdWxlLiIvY29udHJvbGxlcnMvIjsKCQkkbGliT2JqID0gbmV3IEZvcmtfTGliKCk7CgkJdHJ5CgkJewoJCQlpZigkbW9kdWxlICE9IiIgJiYgJGNvbnRyb2xsZXIgIT0iIikKCQkJewoJCQkJaWYoaXNfZmlsZSgkcGF0aC4kY29udHJvbGxlci4iLnBocCIpKQoJCQkJewoJCQkJCXVubGluaygkcGF0aC4kY29udHJvbGxlci4iLnBocCIpOwoJCQkJfQoJCQkJaWYoaXNfZGlyKCRfU0VSVkVSWydET0NVTUVOVF9ST09UJ10uIi8iLiRHTE9CQUxTWydob3N0J10uIi9tb2R1bGVzLyIuJG1vZHVsZS4iL3ZpZXdzLyIuc3RyX3JlcGxhY2UoIkNvbnRyb2xsZXIiLCAiIiwgJGNvbnRyb2xsZXIpLiIvIikpCgkJCQkkZmlsZXMgPSBzY2FuZGlyKCRfU0VSVkVSWydET0NVTUVOVF9ST09UJ10uIi8iLiRHTE9CQUxTWydob3N0J10uIi9tb2R1bGVzLyIuJG1vZHVsZS4iL3ZpZXdzLyIuc3RyX3JlcGxhY2UoIkNvbnRyb2xsZXIiLCAiIiwgJGNvbnRyb2xsZXIpLiIvIik7IC8vIGdldCBhbGwgZmlsZSBuYW1lcwoJCQkJZm9yZWFjaCgkZmlsZXMgYXMgJGZpbGUpeyAvLyBpdGVyYXRlIGZpbGVzCgkJCQkgIGlmKGlzX2ZpbGUoJF9TRVJWRVJbJ0RPQ1VNRU5UX1JPT1QnXS4iLyIuJEdMT0JBTFNbJ2hvc3QnXS4iL21vZHVsZXMvIi4kbW9kdWxlLiIvdmlld3MvIi5zdHJfcmVwbGFjZSgiQ29udHJvbGxlciIsICIiLCAkY29udHJvbGxlcikuIi8iLiRmaWxlKSkKCQkJCSAgICBAdW5saW5rKCRfU0VSVkVSWydET0NVTUVOVF9ST09UJ10uIi8iLiRHTE9CQUxTWydob3N0J10uIi9tb2R1bGVzLyIuJG1vZHVsZS4iL3ZpZXdzLyIuc3RyX3JlcGxhY2UoIkNvbnRyb2xsZXIiLCAiIiwgJGNvbnRyb2xsZXIpLiIvIi4kZmlsZSk7IC8vIGRlbGV0ZSBmaWxlCgkJCQl9CgkJCQkvL3ByaW50X3IoJGZpbGVzKTsKCQkJCUBybWRpcigkX1NFUlZFUlsnRE9DVU1FTlRfUk9PVCddLiIvIi4kR0xPQkFMU1snaG9zdCddLiIvbW9kdWxlcy8iLiRtb2R1bGUuIi92aWV3cy8iLnN0cl9yZXBsYWNlKCJDb250cm9sbGVyIiwgIiIsICRjb250cm9sbGVyKS4iLyIpOwoJCQkJcmV0dXJuIDE7CgkJCX0KCQkJZWxzZQoJCQl7CgkJCQlyZXR1cm4gIlNvbWV0aGluZyB3ZW50IHdyb25nLlBsZWFzZSB0cnkgYWdhaW4gaW4gYSBtb21lbnQuIjsKCQkJfQoJCX0KCQljYXRjaChFeGNlcHRpb24gJGUpCgkJewoJCQlyZXR1cm4gJGUtPmdldE1lc3NhZ2UoKTsKCQl9CgkJCgl9Cg==',
//       ),
//       'createView' => 
//       array (
//         'params' => 
//         array (
//           0 => 'module',
//           1 => 'controller',
//           2 => 'action',
//         ),
//         'code' => 'CWZ1bmN0aW9uIGNyZWF0ZVZpZXcoJG1vZHVsZSwkY29udHJvbGxlciwkYWN0aW9uKQoJewoJCSRwYXRoID0gJF9TRVJWRVJbJ0RPQ1VNRU5UX1JPT1QnXS4iLyIuJEdMT0JBTFNbJ2hvc3QnXS4iL21vZHVsZXMvIi4kbW9kdWxlOwoJCWlmKCFpc19kaXIoJHBhdGguIi92aWV3cy8iKSkKCQl7CgkJCW1rZGlyKCRwYXRoLiIvdmlld3MvIik7CQoJCX0KCQlpZighaXNfZGlyKCRwYXRoLiIvdmlld3MvJGNvbnRyb2xsZXIvIikpCgkJewoJCQlta2RpcigkcGF0aC4iL3ZpZXdzLyRjb250cm9sbGVyLyIpOwkKCQl9CgkJaWYoIWlzX2ZpbGUoJHBhdGguIi92aWV3cy8kY29udHJvbGxlci8kYWN0aW9uLnBodG1sIikpCgkJewoJCQkkZmlsZSA9IGZvcGVuKCRwYXRoLiIvdmlld3MvJGNvbnRyb2xsZXIvJGFjdGlvbi5waHRtbCIsInciKTsKCQkJJGNvbnRlbnQgPSBmaWxlX2dldF9jb250ZW50cygkX1NFUlZFUlsnRE9DVU1FTlRfUk9PVCddLiIvIi4kR0xPQkFMU1snaG9zdCddLiIvbGliL3RlbXBsYXRlcy92aWV3Iik7CgkJCSRjb250ZW50ID0gc3RyX3JlcGxhY2UoInthcHBuYW1lfSIsIEFQUF9OQU1FLCAkY29udGVudCk7CgkJCWZpbGVfcHV0X2NvbnRlbnRzKCRwYXRoLiIvdmlld3MvJGNvbnRyb2xsZXIvJGFjdGlvbi5waHRtbCIsIHN0cl9yZXBsYWNlKCJ7e2FjdGlvbm5hbWV9fSIsICRhY3Rpb24sICRjb250ZW50KSk7CgkJfQoJCWVsc2UKCQl7CgkJCXJldHVybiAiLTEiOy8vIHZpZXcgYWxyZWFkeSBleGlzdHMKCQl9Cgl9Cg==',
//       ),
//       'createAction' => 
//       array (
//         'params' => 
//         array (
//           0 => 'module',
//           1 => 'controller',
//           2 => 'action',
//           3 => 'isView',
//         ),
//         'code' => 'CWZ1bmN0aW9uIGNyZWF0ZUFjdGlvbigkbW9kdWxlLCRjb250cm9sbGVyLCRhY3Rpb24sJGlzVmlldykKCXsKCQkvL3JldHVybiAkbW9kdWxlLiJfIi4kY29udHJvbGxlcjsKCQlpbmNsdWRlX29uY2UgJF9TRVJWRVJbJ0RPQ1VNRU5UX1JPT1QnXS4iLyIuJEdMT0JBTFNbJ2hvc3QnXS4iL21vZHVsZXMvIi4kbW9kdWxlLiIvY29udHJvbGxlcnMvIi4kY29udHJvbGxlci4iLnBocCI7CgkJJHBhdGggPSAkX1NFUlZFUlsnRE9DVU1FTlRfUk9PVCddLiIvIi4kR0xPQkFMU1snaG9zdCddLiIvbW9kdWxlcy8iLiRtb2R1bGU7CgkJaWYoJGlzVmlldz09ImZhbHNlIikKCQl7CgkJCSRjb2RlPSckdGhpcy0+dmlld1JlcXVpcmVkPWZhbHNlOyc7CgkJfQoJCWVsc2UKCQl7CgkJCSRjb2RlPSIiOwoJCQkkcmVzID0gJHRoaXMtPmNyZWF0ZVZpZXcoJG1vZHVsZSxzdHJfcmVwbGFjZSgiQ29udHJvbGxlciIsICIiLCAkY29udHJvbGxlciksJGFjdGlvbik7CgkJCWlmKCRyZXM9PS0xKQoJCQl7CgkJCQlyZXR1cm4gIlZpZXcgZmlsZSAiLiRhY3Rpb24uIi5waHRtbCBBbHJlYWR5IGV4aXN0cy4gQWN0aW9uICRhY3Rpb24gQ3JlYXRlZC4iOwoJCQl9CgkJfQoJCS8vY29kZSB0byBjcmVhdGUgCgkJJGNvZG1vZCA9IG5ldyBDb2RlTW9kKCk7CgkJJHJlcyA9ICRjb2Rtb2QtPmFkZG1ldGhvZCgkbW9kdWxlLiJfIi4kY29udHJvbGxlciwkYWN0aW9uLiJBY3Rpb24iLGFycmF5KCksJGNvZGUpOwoJCWlmKCRyZXM9PTEpCgkJewoJCQlyZXR1cm4gMTsKCQl9CgkJZWxzZQoJCXsKCQkJcmV0dXJuICRyZXM7CgkJfQoJfQo=',
//       ),
//     ),
//   ),
//   'codemod' => 
//   array (
//     'properties' => 
//     array (
//     ),
//     'methods' => 
//     array (
//       'addmethod' => 
//       array (
//         'params' => 
//         array (
//           0 => 'class',
//           1 => 'methodname',
//           2 => 'params',
//           3 => 'code',
//         ),
//         'code' => 'CWZ1bmN0aW9uIGFkZG1ldGhvZCgkY2xhc3MsJG1ldGhvZG5hbWUsJHBhcmFtcz1hcnJheSgpLCRjb2RlPSIiKQoJewoJCSRzdHIgPSc8P3BocCcuIiBcbiBcbiI7CgkJJHBhcmVudGNsYXNzID0gZ2V0X3BhcmVudF9jbGFzcygkY2xhc3MpOwoJCSRwYXJlbnQ9IiI7CgkJaWYoJHBhcmVudGNsYXNzIT1udWxsKQoJCXsKCQkJJHBhcmVudD0iZXh0ZW5kcyAkcGFyZW50Y2xhc3MiOwoJCX0KCQkkc3RyIC49Ilx0Y2xhc3MgJGNsYXNzICRwYXJlbnRcblx0eyBcbiAiOwoJCS8vZWNobyAkcGFyZW50Y2xhc3M7CgkJJG1ldGhvZHMgPSBhcnJheSgpOwoJCSRtZXRob2RzW109Il9fY29uc3RydWN0IjsKCQkkbWV0aG9kcyA9IGFycmF5X21lcmdlKCRtZXRob2RzLGFycmF5X2RpZmYoZ2V0X2NsYXNzX21ldGhvZHMoJGNsYXNzKSxnZXRfY2xhc3NfbWV0aG9kcygiQ29udHJvbGxlciIpKSk7CgkJCgkJCgkJaWYoaW5fYXJyYXkoJG1ldGhvZG5hbWUsICRtZXRob2RzKSkKCQl7CgkJCXJldHVybiAiTWV0aG9kIGFscmVhZHkgZXhpc3RzLiI7CgkJfQoJCQoJCWZvcmVhY2ggKCRtZXRob2RzIGFzICRtZXRob2QpIAoJCXsKCQkJJGZ1bmMgPSBuZXcgUmVmbGVjdGlvbk1ldGhvZCgkY2xhc3MsJG1ldGhvZCk7CgkJCQoJCQkkZmlsZW5hbWUgPSAkZnVuYy0+Z2V0RmlsZU5hbWUoKTsKCQkJLy9wcmludF9yKCRmdW5jKTsKCQkJJHN0YXJ0X2xpbmUgPSAkZnVuYy0+Z2V0U3RhcnRMaW5lKCkgLSAxOyAvLyBpdCdzIGFjdHVhbGx5IC0gMSwgb3RoZXJ3aXNlIHlvdSB3b250IGdldCB0aGUgZnVuY3Rpb24oKSBibG9jawoJCQkkZW5kX2xpbmUgPSAkZnVuYy0+Z2V0RW5kTGluZSgpOwoJCQkkbGVuZ3RoID0gJGVuZF9saW5lIC0gJHN0YXJ0X2xpbmU7CgkJCS8qZWNobyAkZmlsZW5hbWU7CgkJCWVjaG8gJHN0YXJ0X2xpbmU7CgkJCWVjaG8gJGVuZF9saW5lOyovCgkJCSRzb3VyY2UgPSBmaWxlKCRmaWxlbmFtZSk7CgkJCSRib2R5ID0gaW1wbG9kZSgiIiwgYXJyYXlfc2xpY2UoJHNvdXJjZSwgJHN0YXJ0X2xpbmUsICRsZW5ndGgpKTsKCQkJJHN0ciAuPSAkYm9keTsKCQkJLy9lY2hvICRib2R5LiI8YnIvPiI7CgkJfQoJCQoJCWlmKGNvdW50KCRwYXJhbXMpPjApCgkJJHN0ciAuPSJcblx0XHRwdWJsaWMgZnVuY3Rpb24gJG1ldGhvZG5hbWUoJCIuaW1wbG9kZSgiLCQiLCAkcGFyYW1zKS4iKVxuXHRcdHtcblx0XHRcdCIuJGNvZGUuIiBcblx0XHR9XG4iOwoJCWVsc2UKCQkkc3RyIC49IlxuXHRcdHB1YmxpYyBmdW5jdGlvbiAkbWV0aG9kbmFtZSgpXG5cdFx0e1xuXHRcdFx0Ii4kY29kZS4iIFxuXHRcdH1cbiI7CgkJJHN0ciAuPSAiIFxuIFxuXHR9IFxuICIuJz8+JzsKCQkvL2VjaG8gIjxwcmU+Ii5odG1sc3BlY2lhbGNoYXJzKCRzdHIpLiI8L3ByZT4iOwoJCWZpbGVfcHV0X2NvbnRlbnRzKCRmaWxlbmFtZSwgJHN0cik7CgkJcmV0dXJuIDE7CgoJfQo=',
//       ),
//     ),
//   ),
//   'appconfig' => 
//   array (
//     'properties' => 
//     array (
//       0 => 'ini',
//       1 => 'host',
//     ),
//     'methods' => 
//     array (
//       '__construct' => 
//       array (
//         'params' => 
//         array (
//           0 => 'ini',
//           1 => 'host',
//         ),
//         'code' => 'CWZ1bmN0aW9uIF9fY29uc3RydWN0KCRpbmk9J2FwcGxpY2F0aW9uJywkaG9zdD1udWxsKQoJewoJCWlmKCRpbmkgIT1udWxsKQoJCSR0aGlzLT5pbmkgPSAkaW5pOwoJCWlmKCRob3N0ICE9bnVsbCkKCQkkdGhpcy0+aG9zdCA9ICRob3N0OwoJfQo=',
//       ),
//       'get' => 
//       array (
//         'params' => 
//         array (
//           0 => 'prop',
//         ),
//         'code' => 'CWZ1bmN0aW9uIGdldCgkcHJvcD0nJykKCXsKCQkkaG9zdD1pc3NldCgkdGhpcy0+aG9zdCk/JHRoaXMtPmhvc3Q6JEdMT0JBTFNbJ2hvc3QnXTsKCQkkaW5pRGF0YSA9IHBhcnNlX2luaV9maWxlKCRfU0VSVkVSWydET0NVTUVOVF9ST09UJ10uIi8iLiRob3N0LiIvQXBwLyIuJHRoaXMtPmluaS4iLmluaSIpOwoJCWlmKGVtcHR5KCRwcm9wKSkKCQl7CgkJCXJldHVybiAkaW5pRGF0YTsKCQl9CgkJZWxzZQoJCXsKCQkJaWYoaXNzZXQoJGluaURhdGFbJHByb3BdKSkKCQkJewoJCQkJcmV0dXJuICRpbmlEYXRhWyRwcm9wXTsKCQkJfQoJCQllbHNlCgkJCXsKCQkJCXJldHVybiAnJzsKCQkJfQoJCX0KCX0K',
//       ),
//       'appName' => 
//       array (
//         'params' => 
//         array (
//         ),
//         'code' => 'CXB1YmxpYyBzdGF0aWMgZnVuY3Rpb24gYXBwTmFtZSgpCgl7CgkJcmV0dXJuICRHTE9CQUxTWydjb25maWcnXVsnYXBwbGljYXRpb24nXTsKCX0K',
//       ),
//       'getList' => 
//       array (
//         'params' => 
//         array (
//         ),
//         'code' => 'CWZ1bmN0aW9uIGdldExpc3QoKQoJewoJCSRwYXRoID0gJF9TRVJWRVJbJ0RPQ1VNRU5UX1JPT1QnXS4iLyIuJEdMT0JBTFNbJ2hvc3QnXS4iL0FwcCI7CgkJJGRpcl9oYW5kbGUgPSBAb3BlbmRpcigkcGF0aCkgb3IgZGllKCJVbmFibGUgdG8gb3BlbiAkcGF0aCIpOwogICAgICAgICAgICAgCiAgICAgICAgICAgICAgLy9MZWF2ZSBvbmx5IHRoZSBsYXN0ZXN0IGZvbGRlciBuYW1lCiAgICAgICRkaXJuYW1lID0gQGVuZChAZXhwbG9kZSgiLyIsICRwYXRoKSk7CiAgICAgICRhcnI9YXJyYXkoKTsKICAgICAgd2hpbGUgKGZhbHNlICE9PSAoJGZpbGUgPSByZWFkZGlyKCRkaXJfaGFuZGxlKSkpCiAgICAgIHsKICAgICAgICAgIGlmKCRmaWxlIT0iLiIgJiYgJGZpbGUhPSIuLiIpCiAgICAgICAgICB7CiAgICAgICAgICAgICAgJGNvbnRlbnQgPSBmaWxlX2dldF9jb250ZW50cygkcGF0aC4iLyIuJGZpbGUpOwogICAgICAgICAgICAgICRhcnJbJGZpbGVdPSRjb250ZW50OwogICAgICAgICAgfQogICAgICB9CiAgICAgIHJldHVybiAkYXJyOwoJfQo=',
//       ),
//     ),
//   ),
//   'exceptions' => 
//   array (
//     'properties' => 
//     array (
//       0 => 'type',
//       1 => 'exceptions',
//     ),
//     'methods' => 
//     array (
//       '__construct' => 
//       array (
//         'params' => 
//         array (
//           0 => 'type',
//         ),
//         'code' => 'CWZ1bmN0aW9uIF9fY29uc3RydWN0KCR0eXBlKQoJewoJCSR0aGlzLT50eXBlPSR0eXBlOwoJCSRob3N0PSRHTE9CQUxTWydob3N0J107CgkJJHRoaXMtPmV4Y2VwdGlvbnMgPSBwYXJzZV9pbmlfZmlsZSgkX1NFUlZFUlsnRE9DVU1FTlRfUk9PVCddLiIvIi4kaG9zdC4iL0FwcC9leGNlcHRpb25zLmluaSIpOwoJfQo=',
//       ),
//       'throwException' => 
//       array (
//         'params' => 
//         array (
//         ),
//         'code' => 'CWZ1bmN0aW9uIHRocm93RXhjZXB0aW9uKCkKCXsKCgkJc3dpdGNoKCR0aGlzLT50eXBlKQoJCXsKCQkJY2FzZSAiVU5ERUZJTkVEX01PRFVMRV9FWENFUFRJT04iOgoJCQkJCQlyZXR1cm4gc3ByaW50ZigkdGhpcy0+ZXhjZXB0aW9uc1snVU5ERUZJTkVEX01PRFVMRV9FWENFUFRJT04nXSwkR0xPQkFMU1sndHJhY0tfaW5mbyddWydtb2R1bGUnXSk7CgkJCQkJCWJyZWFrOwoJCQljYXNlICJVTkRFRklORURfQ09OVFJPTExFUl9FWENFUFRJT04iOgoJCQkJCQlyZXR1cm4gc3ByaW50ZigkdGhpcy0+ZXhjZXB0aW9uc1snVU5ERUZJTkVEX0NPTlRST0xMRVJfRVhDRVBUSU9OJ10sJEdMT0JBTFNbJ3RyYWNLX2luZm8nXVsnY29udHJvbGxlciddLCRHTE9CQUxTWyd0cmFjS19pbmZvJ11bJ21vZHVsZSddKTsKCQkJCQkJYnJlYWs7CQoJCQljYXNlICJDT05UUk9MTEVSX0NMQVNTX0VYQ0VQVElPTiI6CgkJCQkJCXJldHVybiBzcHJpbnRmKCR0aGlzLT5leGNlcHRpb25zWydDT05UUk9MTEVSX0NMQVNTX0VYQ0VQVElPTiddLCRHTE9CQUxTWyd0cmFjS19pbmZvJ11bJ21vZHVsZSddLiJfIi4kR0xPQkFMU1sndHJhY0tfaW5mbyddWydjb250cm9sbGVyJ10uIkNvbnRyb2xsZXIiLCRHTE9CQUxTWyd0cmFjS19pbmZvJ11bJ21vZHVsZSddKTsKCQkJCQkJYnJlYWs7CgkJCWNhc2UgIlVOREVGSU5FRF9BQ1RJT05fRVhDRVBUSU9OIjoKCQkJCQkJcmV0dXJuIHNwcmludGYoJHRoaXMtPmV4Y2VwdGlvbnNbJ1VOREVGSU5FRF9BQ1RJT05fRVhDRVBUSU9OJ10sJEdMT0JBTFNbJ3RyYWNLX2luZm8nXVsnYWN0aW9uJ10sJEdMT0JBTFNbJ3RyYWNLX2luZm8nXVsnY29udHJvbGxlciddLCRHTE9CQUxTWyd0cmFjS19pbmZvJ11bJ21vZHVsZSddKTsKCQkJCQkJYnJlYWs7CQoJCQljYXNlICJNSVNTSU5HX1ZJRVdfRklMRSI6CgkJCQkJCXJldHVybiBzcHJpbnRmKCR0aGlzLT5leGNlcHRpb25zWydNSVNTSU5HX1ZJRVdfRklMRSddLCRHTE9CQUxTWyd0cmFjS19pbmZvJ11bJ2FjdGlvbiddLCRHTE9CQUxTWyd0cmFjS19pbmZvJ11bJ2FjdGlvbiddLCRHTE9CQUxTWyd0cmFjS19pbmZvJ11bJ2NvbnRyb2xsZXInXSwkR0xPQkFMU1sndHJhY0tfaW5mbyddWydtb2R1bGUnXSk7CgkJCQkJCWJyZWFrOwkKCQkJY2FzZSAiTUlTU0lOR19MQVlPVVRfRklMRSI6CgkJCQkJCXJldHVybiBzcHJpbnRmKCR0aGlzLT5leGNlcHRpb25zWydNSVNTSU5HX0xBWU9VVF9GSUxFJ10sJEdMT0JBTFNbJ2Vycm9yZGF0YSddWydsYXlvdXQnXSk7CgkJCQkJCWJyZWFrOwoJCQljYXNlICJJTlZBTElEX1ZJRVdfUEFSQU1TIjoKCQkJCQkJCXJldHVybiBzcHJpbnRmKCR0aGlzLT5leGNlcHRpb25zWydJTlZBTElEX1ZJRVdfUEFSQU1TJ10sJEdMT0JBTFNbJ3RyYWNLX2luZm8nXVsnYWN0aW9uJ10sJEdMT0JBTFNbJ3RyYWNLX2luZm8nXVsnY29udHJvbGxlciddLCRHTE9CQUxTWyd0cmFjS19pbmZvJ11bJ21vZHVsZSddKTsKCQkJCQkJYnJlYWs7CgkJCWNhc2UgIklOVkFMSURfVklFV19BQ0NFU1MiOgoJCQkJCQkJcmV0dXJuIHNwcmludGYoJHRoaXMtPmV4Y2VwdGlvbnNbJ0lOVkFMSURfVklFV19BQ0NFU1MnXSwkR0xPQkFMU1sndHJhY0tfaW5mbyddWydhY3Rpb24nXSwkR0xPQkFMU1sndHJhY0tfaW5mbyddWydjb250cm9sbGVyJ10pOwoJCQkJCQlicmVhazsKCQkJY2FzZSAiTUlTU0lOR19QQVJUSUFMX1ZJRVdfRklMRSI6CgkJCQkJCQlyZXR1cm4gc3ByaW50ZigkdGhpcy0+ZXhjZXB0aW9uc1snTUlTU0lOR19QQVJUSUFMX1ZJRVdfRklMRSddLCRHTE9CQUxTWyd0cmFjS19pbmZvJ11bJ3BhcnRpYWwnXSwkR0xPQkFMU1sndHJhY0tfaW5mbyddWydzb3VyY2UnXSwkR0xPQkFMU1sndHJhY0tfaW5mbyddWydhY3Rpb24nXSwkR0xPQkFMU1sndHJhY0tfaW5mbyddWydjb250cm9sbGVyJ10sJEdMT0JBTFNbJ3RyYWNLX2luZm8nXVsnbW9kdWxlJ10pOwoJCQkJCQlicmVhazsJCQkJCQkJCQkJCQkJCQkKCQkJZGVmYXVsdDoKCQkJCQkJcmV0dXJuIHNwcmludGYoJHRoaXMtPmV4Y2VwdGlvbnNbJ2V4Y2VwdGlvbl8nLiR0aGlzLT50eXBlXSwkdGhpcy0+dHlwZSk7CgkJCQkJCWJyZWFrOwoJCX0KCX0K',
//       ),
//     ),
//   ),
//   'usersystem' => 
//   array (
//     'properties' => 
//     array (
//       0 => 'class',
//       1 => 'role',
//     ),
//     'methods' => 
//     array (
//       '__construct' => 
//       array (
//         'params' => 
//         array (
//           0 => 'class',
//           1 => 'role',
//         ),
//         'code' => 'CWZ1bmN0aW9uIF9fY29uc3RydWN0KCRjbGFzcywkcm9sZSkKCXsKCQkkdGhpcy0+Y2xhc3M9JGNsYXNzOwoJCSR0aGlzLT5yb2xlPSRyb2xlOwoJfQo=',
//       ),
//       'validate' => 
//       array (
//         'params' => 
//         array (
//         ),
//         'code' => 'CWZ1bmN0aW9uIHZhbGlkYXRlKCkKCXsKCQlpZihpc3NldCgkX1NFU1NJT05bJ3VzZXInXSkgJiYgaXNzZXQoJF9TRVNTSU9OWyd1c2VyJ11bJ3Rva2VuJ10pKQoJCXsKCQkJCgkJCSRjb250ZXh0ID0gbmV3IERiQ29udGV4dCgpOwoJCQkkY2xhc3M9JHRoaXMtPmNsYXNzOwoJCQkkdXNlciA9IG5ldyAkY2xhc3MoKTsKCQkJJHVzZXItPnVzZXJuYW1lPSRfU0VTU0lPTlsndXNlciddWyd1c2VybmFtZSddOwoJCQkkdXNlci0+cm9sZSA9ICR0aGlzLT5yb2xlOwoJCQkkcm93ID0gJGNvbnRleHQtPkdldCgkdXNlciktPnRvQXJyYXkoKTsKCQkJLy9wcmludF9yKCRyb3cpOwoJCQlpZiggY291bnQoJHJvdykgPjAgJiYgaXNzZXQoJHJvd1sndG9rZW4nXSkgJiYgJHJvd1sndG9rZW4nXT09JF9TRVNTSU9OWyd1c2VyJ11bJ3Rva2VuJ10pCgkJCXsKCQkJCSR0b2tlbiA9IHVuaXFpZCgpIC4gJ18nIC4gbWQ1KG10X3JhbmQoKSk7CgkJCQlyZXR1cm4gdHJ1ZTsKCQkJfQoJCQlyZXR1cm4gZmFsc2U7CgkJfQoJCWVsc2UKCQl7CgkJCS8vZWNobyAibm90IHNldCI7CgkJCXJldHVybiBmYWxzZTsKCQl9Cgl9Cg==',
//       ),
//       'processLogin' => 
//       array (
//         'params' => 
//         array (
//           0 => 'username',
//           1 => 'password',
//         ),
//         'code' => 'CWZ1bmN0aW9uIHByb2Nlc3NMb2dpbigkdXNlcm5hbWUsJHBhc3N3b3JkKQoJewoJCSRjb250ZXh0ID0gbmV3IERiQ29udGV4dCgpOwoJCS8vIENyZWF0ZSBvYmplY3Qgb2YgdXNlcnMgdGFibGUgaW4gZm9ya0FkbWluIERCLgoJCSR1c2VyID0gbmV3ICR0aGlzLT5jbGFzcygpOwoJCSR1c2VyLT51c2VybmFtZT0kdXNlcm5hbWU7CgkJJHVzZXItPnBhc3N3b3JkPSRwYXNzd29yZDsKCQkkdXNlci0+cm9sZT0kdGhpcy0+cm9sZTsKCQkvL3ByaW50X3IoJHVzZXIpO2RpZTsKCgkJJHVzZXIgPSAkY29udGV4dC0+R2V0KCR1c2VyKS0+dG9PYmplY3QoKTsKCgkJaWYoJHVzZXJuYW1lICE9IiIgJiYgJHBhc3N3b3JkICE9IiIpCgkJewkKCQkJCgkJCWlmKGNvdW50KCR1c2VyKT4wKQoJCQl7CgkJCQkvLyBsb2dpbiBzdWNjZXNmdWwKCgkJCQkkX1NFU1NJT05bJ3VzZXInXT1hcnJheSgpOwoJCQkJJF9TRVNTSU9OWyd1c2VyJ11bJ3VzZXJuYW1lJ109JHVzZXJuYW1lOwoJCQkJJF9TRVNTSU9OWyd1c2VyJ11bJ2lkJ109JHVzZXItPmlkOwoJCQkJJF9TRVNTSU9OWyd1c2VyJ11bJ2NkYXRlJ109JHVzZXItPmNkYXRlOwoJCQkJJHRva2VuID0gdW5pcWlkKCkgLiAnXycgLiBtZDUobXRfcmFuZCgpKTsKCQkJCSRfU0VTU0lPTlsndXNlciddWyd0b2tlbiddPSR0b2tlbjsKCQkJCSR1c2VyLT50b2tlbj0kdG9rZW47CgkJCQkvLyB1cGRhdGUgdG9rZW4gaW4gREIKCQkJCSRjb250ZXh0LT5VcGRhdGUoJHVzZXIpOwoJCQkJJHVzZXJfcHJvZmlsZSA9IG5ldyB1c2VyX3Byb2ZpbGUoKTsKCQkJCSR1c2VyX3Byb2ZpbGUtPnVzZXJfaWQgPSAkdXNlci0+aWQ7CgkJCQkkdXNlcl9wcm9maWxlID0gJGNvbnRleHQtPkdldCgkdXNlcl9wcm9maWxlKS0+dG9BcnJheSgpOwoJCQkJLy9wcmludF9yKCR1c2VyX3Byb2ZpbGUpOwoKCQkJCSRfU0VTU0lPTlsndXNlciddID0gYXJyYXlfbWVyZ2UoJF9TRVNTSU9OWyd1c2VyJ10sJHVzZXJfcHJvZmlsZSk7CgoJCQkJLy9lY2hvICR1c2VyLT5pZC4iSEhFSEhFIjsKCQkJCXJldHVybiB0cnVlOwoJCQl9CgkJfQoJCXJldHVybiBmYWxzZTsKCX0K',
//       ),
//       'add' => 
//       array (
//         'params' => 
//         array (
//           0 => 'name',
//           1 => 'email',
//           2 => 'password',
//         ),
//         'code' => 'CWZ1bmN0aW9uIGFkZCgkbmFtZSwkZW1haWwsJHBhc3N3b3JkKQoJewoJCSR1c2VyID0gbmV3ICR0aGlzLT5jbGFzcygpOwoJCSR1c2VyLT51c2VybmFtZT0kZW1haWw7CgkJJHVzZXItPnBhc3N3b3JkPSRwYXNzd29yZDsKCQkkdXNlci0+cm9sZT0kdGhpcy0+cm9sZTsKCQkkdXNlci0+dG9rZW49IiI7CgkJJGNvbnRleHQgPSBuZXcgRGJDb250ZXh0KCk7CgkJdHJ5CgkJewoJCQkkcmVzID0gJGNvbnRleHQtPkFkZCgkdXNlcik7CgkJfQoJCWNhdGNoKEV4Y2VwdGlvbiAkZSkKCQl7CgkJCSRyZXMgPSAkZS0+Z2V0TWVzc2FnZSgpOwoJCQkvLyRyZXMgPSBteXNxbF9lcnJubygpOwoJCX0KCQlpZihlbXB0eSgkcmVzKSkKCQl7CgkJCXJldHVybiAic3VjY2VzcyI7CgkJfQoJCWVsc2UKCQl7CgkJCXJldHVybiAiZXJyb3IiOwoJCX0KCgl9Cg==',
//       ),
//     ),
//   ),
//   'layout' => 
//   array (
//     'properties' => 
//     array (
//       0 => 'controllerObj',
//       1 => 'layoutPath',
//       2 => 'lcontroller',
//       3 => 'layoutName',
//       4 => 'layout',
//       5 => 'meta',
//       6 => 'headers',
//       7 => 'view',
//       8 => 'head',
//       9 => 'js',
//       10 => 'css',
//       11 => 'title',
//       12 => '_helper',
//     ),
//     'methods' => 
//     array (
//       '__construct' => 
//       array (
//         'params' => 
//         array (
//           0 => 'cObj',
//           1 => 'layoutName',
//         ),
//         'code' => 'IHB1YmxpYyBmdW5jdGlvbiBfX2NvbnN0cnVjdCgkY09iaiwkbGF5b3V0TmFtZSkNCiB7DQogCSR0aGlzLT5oZWFkPWFycmF5KCk7DQogCSR0aGlzLT5qcz1hcnJheSgpOw0KIAkkdGhpcy0+Y3NzPWFycmF5KCk7DQogCSR0aGlzLT5tZXRhPWFycmF5KCk7DQogCSR0aGlzLT5oZWFkZXJzPWFycmF5KCk7DQogCSR0aGlzLT5jb250cm9sbGVyT2JqPSRjT2JqOw0KIAkkdGhpcy0+bGF5b3V0UGF0aD0kbGF5b3V0TmFtZTsNCiAJJHRoaXMtPmxheW91dE5hbWU9JGNPYmotPmxheW91dDsNCiAJJHRoaXMtPl9oZWxwZXIgPSBuZXcgRGVmYXVsdEhlbHBlcigpOw0KIAkkaG9zdD0kR0xPQkFMU1snaG9zdCddOw0KIAkkY3BhdGg9JF9TRVJWRVJbJ0RPQ1VNRU5UX1JPT1QnXS4kaG9zdC4iL2xheW91dHMvY29udHJvbGxlcnMvIi4kY09iai0+bGF5b3V0LiJsYXlvdXRDb250cm9sbGVyLnBocCI7DQogCSR0aGlzLT50aXRsZT0kdGhpcy0+Y29udHJvbGxlck9iai0+dGl0bGU7DQogCWlmKGZpbGVfZXhpc3RzKCRjcGF0aCkpDQogCXsNCiAJCWluY2x1ZGUgJGNwYXRoOw0KIAkJJGxheW91dENvbnRyb2xsZXJOYW1lPSRjT2JqLT5sYXlvdXQuImxheW91dENvbnRyb2xsZXIiOw0KIAkJaWYoY2xhc3NfZXhpc3RzKCRsYXlvdXRDb250cm9sbGVyTmFtZSkpDQogCQl7DQogCQkJJHRoaXMtPmxjb250cm9sbGVyPW5ldyAkbGF5b3V0Q29udHJvbGxlck5hbWUoKTsNCiAJCX0NCiAJCWVsc2UNCiAJCXsNCiAJCQl0cmlnZ2VyX2Vycm9yKCRjT2JqLT5sYXlvdXQuImxheW91dENvbnRyb2xsZXIgQ2xhc3MgZG9lcyd0IGV4aXN0cy4iKTsNCiAJCX0NCiAJfQ0KIAllbHNlDQogCXsNCiAJCS8vdHJpZ2dlcl9lcnJvcigkY09iai0+bGF5b3V0LiJsYXlvdXRDb250cm9sbGVyIGlzIG5vdCBkZWZpbmVkLiIsRV9VU0VSX1dBUk5JTkcpOw0KIAl9DQogCWlmKCR0aGlzLT5jb250cm9sbGVyT2JqLT52aWV3UmVxdWlyZWQpIC8vIHVwZGF0ZSA6IHZpZXcgaXMgbm90IGluY2x1ZGVkIGJ5IGRlZmF1bHQgLCBjYWxsIHZpZXcoKSB0byBpbmNsdWRlDQoJew0KDQoJCWlmKGZpbGVfZXhpc3RzKCRfU0VSVkVSWydET0NVTUVOVF9ST09UJ10uJGhvc3QuIi9tb2R1bGVzLyIuJEdMT0JBTFNbJ2ZvcmtvYmonXVsnbW9kdWxlJ10uIi92aWV3cy8iLiRHTE9CQUxTWydmb3Jrb2JqJ11bJ2NvbnRyb2xsZXInXS4iLyIuJEdMT0JBTFNbJ2ZvcmtvYmonXVsnYWN0aW9uJ10uIi5waHRtbCIpKQ0KCQl7DQoJCQlvYl9zdGFydCgpOw0KCQkJJGxheSA9IGluY2x1ZGUgJHRoaXMtPmxheW91dFBhdGg7DQoJCQkNCgkJCSRidWZmZXIgPW9iX2dldF9jbGVhbigpOw0KCQkJJGh0bWwgPSAiPCFET0NUWVBFIGh0bWw+XG48aHRtbD5cbiI7DQoJCQkkaHRtbCAuPSI8aGVhZD5cbiI7DQoJCQkkaHRtbCAuPSI8dGl0bGU+Ii4kdGhpcy0+dGl0bGUuIjwvdGl0bGU+XG4iOw0KCQkJJGh0bWwgLj0kdGhpcy0+Z2V0SGVhZGVycygpLiJcbiI7DQoJCQkkaHRtbCAuPSR0aGlzLT5oZWFkRmlsZXMoJHRoaXMtPmNzcywkdGhpcy0+anMpLiJcbiI7DQoJCQkkaHRtbCAuPSI8L2hlYWQ+XG48Ym9keT5cbiI7DQoJCQllY2hvIHRyaW0oJGh0bWwpOw0KCQkJZWNobyAkYnVmZmVyOw0KCQkJZWNobyAiPC9ib2R5PlxuPC9odG1sPiI7DQoJCQkvLyRwYXRoPSRfU0VSVkVSWydET0NVTUVOVF9ST09UJ10uIi8iLiRob3N0LiIvbW9kdWxlcy8iLiRHTE9CQUxTWydmb3Jrb2JqJ11bJ21vZHVsZSddLiIvdmlld3MvIi4kR0xPQkFMU1snZm9ya29iaiddWydjb250cm9sbGVyJ10uIi8iLiRHTE9CQUxTWydmb3Jrb2JqJ11bJ2FjdGlvbiddLiIucGh0bWwiOw0KCQkJLy9jcmVhdGUgdmlldyANCgkJCS8vJHZpZXcgPSBuZXcgVmlldygkdGhpcy0+Y29udHJvbGxlck9iaiwkcGF0aCk7CQ0KCQkJDQoJCX0NCgkJZWxzZQ0KCQl7DQoNCiAgICAJCXRyaWdnZXJfZXJyb3IoIk1JU1NJTkdfVklFV19GSUxFIixFX1VTRVJfRVJST1IpOyAvLyBtaXNzaW5nIHZpZXcvLyBtaXNzaW5nIHZpZXcNCgkJfQ0KCX0NCgllbHNlDQoJew0KCQlvYl9zdGFydCgpOw0KCQkJJGxheSA9IGluY2x1ZGUgJHRoaXMtPmxheW91dFBhdGg7DQoJCQkNCgkJCSRidWZmZXIgPW9iX2dldF9jbGVhbigpOw0KCQkJJGh0bWwgPSAiPCFET0NUWVBFIGh0bWw+XG48aHRtbD5cbiI7DQoJCQkkaHRtbCAuPSI8aGVhZD5cbiI7DQoJCQkkaHRtbCAuPSI8dGl0bGU+Ii4kdGhpcy0+dGl0bGUuIjwvdGl0bGU+XG4iOw0KCQkJJGh0bWwgLj0kdGhpcy0+Z2V0SGVhZGVycygpLiJcbiI7DQoJCQkkaHRtbCAuPSR0aGlzLT5oZWFkRmlsZXMoJHRoaXMtPmNzcywkdGhpcy0+anMpLiJcbiI7DQoJCQkkaHRtbCAuPSI8L2hlYWQ+XG48Ym9keT5cbiI7DQoJCQllY2hvICRodG1sOw0KCQkJZWNobyAkYnVmZmVyOw0KCQkJZWNobyAiPC9ib2R5PlxuPC9odG1sPiI7DQoJfQ0KIAkvL3ByaW50X3IoJHRoaXMtPmNzcyk7DQogfQ0K',
//       ),
//       'partial' => 
//       array (
//         'params' => 
//         array (
//           0 => 'file',
//         ),
//         'code' => 'cHVibGljIGZ1bmN0aW9uIHBhcnRpYWwoJGZpbGUpDQp7DQoJJGhvc3Q9JEdMT0JBTFNbJ2hvc3QnXTsNCg0KCWlmKGZpbGVfZXhpc3RzKCRfU0VSVkVSWydET0NVTUVOVF9ST09UJ10uJGhvc3QuIi9tb2R1bGVzLyIuJEdMT0JBTFNbJ2ZvcmtvYmonXVsnbW9kdWxlJ10uIi92aWV3cy8iLiRHTE9CQUxTWydmb3Jrb2JqJ11bJ2NvbnRyb2xsZXInXS4iLyIuJGZpbGUuIi5waHRtbCIpKQ0KCXsNCgkJDQoJCSRwYXRoPSRfU0VSVkVSWydET0NVTUVOVF9ST09UJ10uJGhvc3QuIi9tb2R1bGVzLyIuJEdMT0JBTFNbJ2ZvcmtvYmonXVsnbW9kdWxlJ10uIi92aWV3cy8iLiRHTE9CQUxTWydmb3Jrb2JqJ11bJ2NvbnRyb2xsZXInXS4iLyIuJGZpbGUuIi5waHRtbCI7DQoJCS8vY3JlYXRlIHZpZXcgDQoJCS8vZWNobyAkcGF0aDsNCgkJJHBhcnRpYWxWaWV3ID0gbmV3IFZpZXcoJHRoaXMtPmNvbnRyb2xsZXJPYmosJHBhdGgsMSk7CSAgICANCgkJJHRoaXMtPmNzcz1hcnJheV9tZXJnZSgkdGhpcy0+Y3NzLCRwYXJ0aWFsVmlldy0+Z2V0Q3NzRmlsZXMoKSk7DQoJCSR0aGlzLT5qcz1hcnJheV9tZXJnZSgkdGhpcy0+anMsJHBhcnRpYWxWaWV3LT5nZXRKc0ZpbGVzKCkpOw0KDQoJfQ0KCWVsc2UNCgl7DQoJCSRHTE9CQUxTWyd0cmFjS19pbmZvJ11bJ3BhcnRpYWwnXT0kZmlsZTsNCgkJJEdMT0JBTFNbJ3RyYWNLX2luZm8nXVsnc291cmNlJ109JHRoaXMtPmxheW91dE5hbWUuIi5waHRtbCBsYXlvdXQiOw0KCQl0cmlnZ2VyX2Vycm9yKCJNSVNTSU5HX1BBUlRJQUxfVklFV19GSUxFIixFX1VTRVJfRVJST1IpOw0KCQkvLyBtaXNzaW5nIHZpZXcNCgl9DQp9DQo=',
//       ),
//       'partialLayout' => 
//       array (
//         'params' => 
//         array (
//           0 => 'file',
//         ),
//         'code' => 'cHVibGljIGZ1bmN0aW9uIHBhcnRpYWxMYXlvdXQoJGZpbGUpDQp7DQoJJGhvc3Q9JEdMT0JBTFNbJ2hvc3QnXTsNCg0KCWlmKGZpbGVfZXhpc3RzKCRfU0VSVkVSWydET0NVTUVOVF9ST09UJ10uJGhvc3QuIi9sYXlvdXRzLyIuJGZpbGUuIi5waHRtbCIpKQ0KCXsNCgkJDQoJCSRwYXRoPSRfU0VSVkVSWydET0NVTUVOVF9ST09UJ10uJGhvc3QuIi9sYXlvdXRzLyIuJGZpbGUuIi5waHRtbCI7DQoJCS8vY3JlYXRlIHZpZXcgDQoJCS8vZWNobyAkcGF0aDsNCgkJJHBhcnRpYWxWaWV3ID0gbmV3IFZpZXcoJHRoaXMtPmNvbnRyb2xsZXJPYmosJHBhdGgsMSk7CSAgICANCgkJJHRoaXMtPmNzcz1hcnJheV9tZXJnZSgkdGhpcy0+Y3NzLCRwYXJ0aWFsVmlldy0+Z2V0Q3NzRmlsZXMoKSk7DQoJCSR0aGlzLT5qcz1hcnJheV9tZXJnZSgkdGhpcy0+anMsJHBhcnRpYWxWaWV3LT5nZXRKc0ZpbGVzKCkpOw0KDQoJfQ0KCWVsc2UNCgl7DQoJCSRHTE9CQUxTWyd0cmFjS19pbmZvJ11bJ3BhcnRpYWwnXT0kZmlsZTsNCgkJJEdMT0JBTFNbJ3RyYWNLX2luZm8nXVsnc291cmNlJ109JHRoaXMtPmxheW91dE5hbWUuIi5waHRtbCBsYXlvdXQiOw0KCQl0cmlnZ2VyX2Vycm9yKCJNSVNTSU5HX1BBUlRJQUxfVklFV19GSUxFIixFX1VTRVJfRVJST1IpOw0KCQkvLyBtaXNzaW5nIHZpZXcNCgl9DQp9DQo=',
//       ),
//       'meta' => 
//       array (
//         'params' => 
//         array (
//           0 => 'nameorarr',
//           1 => 'content',
//         ),
//         'code' => 'cHVibGljIGZ1bmN0aW9uIG1ldGEoJG5hbWVvcmFyciwkY29udGVudD1udWxsKQ0Kew0KCWlmKCRjb250ZW50PT1udWxsKQ0KCXsNCgkJJG1ldGFTdHIgPSAiPG1ldGEgIjsNCgkJZm9yZWFjaCAoJG5hbWVvcmFyciBhcyAka2V5ID0+ICR2YWx1ZSkgew0KCQkJJG1ldGFTdHIgLj0gJGtleS4iPSciLiR2YWx1ZS4iJyAiOw0KCQl9DQoJCSRtZXRhU3RyIC49Ij5cbiI7DQoJCQ0KCX0NCgllbHNlDQoJew0KCQkkbWV0YVN0ciA9ICI8bWV0YSBuYW1lPSciLiRuYW1lb3JhcnIuIicgY29udGVudD0nIi4kY29udGVudC4iJyA+XG4iOw0KCX0NCgkkdGhpcy0+bWV0YVtdID0gJG1ldGFTdHI7DQp9DQo=',
//       ),
//       'headString' => 
//       array (
//         'params' => 
//         array (
//           0 => 'str',
//         ),
//         'code' => 'cHVibGljIGZ1bmN0aW9uIGhlYWRTdHJpbmcoJHN0cikNCnsNCgkkdGhpcy0+aGVhZGVyc1tdID0gJHN0cjsNCg0KfQ0K',
//       ),
//       'title' => 
//       array (
//         'params' => 
//         array (
//         ),
//         'code' => 'IHB1YmxpYyBmdW5jdGlvbiB0aXRsZSgpDQogew0KIAllY2hvICI8dGl0bGU+Ii4kdGhpcy0+dGl0bGUuIjwvdGl0bGU+IjsNCiB9DQo=',
//       ),
//       'headFiles' => 
//       array (
//         'params' => 
//         array (
//           0 => 'cssArr',
//           1 => 'jsArr',
//         ),
//         'code' => 'IHB1YmxpYyBmdW5jdGlvbiBoZWFkRmlsZXMoJGNzc0FyciwkanNBcnIpDQogew0KIAkvL3ByaW50X3IoJHRoaXMtPmNzcyk7DQogCSRzdHJpbmc9IiI7DQogCWZvcmVhY2ggKGFycmF5X3VuaXF1ZSgkanNBcnIpIGFzICRqcykgew0KIAkJJHN0cmluZyAuPSI8c2NyaXB0IHR5cGU9J3RleHQvamF2YXNjcmlwdCcgc3JjPSciLiRqcy4iJz48L3NjcmlwdD5cbiI7DQogCX0NCiAJZm9yZWFjaCAoYXJyYXlfdW5pcXVlKCRjc3NBcnIpIGFzICRjc3MpIHsNCiAJCSRzdHJpbmcgLj0iPGxpbmsgcmVsPSdzdHlsZXNoZWV0JyB0eXBlPSd0ZXh0L2NzcycgaHJlZj0nIi4kY3NzLiInPlxuIjsNCiAJfQ0KIAlyZXR1cm4gJHN0cmluZzsNCiB9DQo=',
//       ),
//       'getHeaders' => 
//       array (
//         'params' => 
//         array (
//         ),
//         'code' => 'IHB1YmxpYyBmdW5jdGlvbiBnZXRIZWFkZXJzKCkNCiB7DQogCSRzdHJpbmc9IiI7DQogCWZvcmVhY2ggKGFycmF5X3VuaXF1ZSgkdGhpcy0+bWV0YSkgYXMgJG1ldGEpIHsNCiAJCSRzdHJpbmcgLj0kbWV0YTsNCiAJfQ0KIAlmb3JlYWNoIChhcnJheV91bmlxdWUoJHRoaXMtPmhlYWRlcnMpIGFzICRoZWFkc3RyKSB7DQogCQkkc3RyaW5nIC49JGhlYWRzdHI7DQogCX0NCiAJcmV0dXJuICRzdHJpbmc7DQoNCiB9DQo=',
//       ),
//       'baseUrl' => 
//       array (
//         'params' => 
//         array (
//         ),
//         'code' => 'IHB1YmxpYyBmdW5jdGlvbiBiYXNlVXJsKCkNCiB7DQogCSRzZXJ2ZXI9JF9TRVJWRVJbJ0hUVFBfSE9TVCddOw0KIAkkdXJsPSAkR0xPQkFMU1snaG9zdCddLiIvc2l0ZSI7DQogCXJldHVybiAkdXJsOw0KIH0NCg==',
//       ),
//       'appBase' => 
//       array (
//         'params' => 
//         array (
//         ),
//         'code' => 'IHB1YmxpYyBmdW5jdGlvbiBhcHBCYXNlKCkNCiB7DQogCSRzZXJ2ZXI9JF9TRVJWRVJbJ0hUVFBfSE9TVCddOw0KIAkkdXJsPSAkR0xPQkFMU1snaG9zdCddOw0KIAlyZXR1cm4gJHVybDsNCiB9DQo=',
//       ),
//       'appendJS' => 
//       array (
//         'params' => 
//         array (
//           0 => 'file',
//           1 => 'path',
//         ),
//         'code' => 'IHB1YmxpYyBmdW5jdGlvbiBhcHBlbmRKUygkZmlsZSwkcGF0aD0nJykNCiB7DQogCWlmKGVtcHR5KCRwYXRoKSl7DQogCQkkdGhpcy0+anNbXT0kdGhpcy0+YmFzZVVybCgpLiIvanMvIi4kZmlsZTsNCiAJfQ0KIAllbHNlIHsNCiAJCSR0aGlzLT5qc1tdPSRwYXRoLiIvIi4kZmlsZTsNCiAJfQ0KCQ0KIH0NCg==',
//       ),
//       'appendCSS' => 
//       array (
//         'params' => 
//         array (
//           0 => 'file',
//           1 => 'path',
//         ),
//         'code' => 'IHB1YmxpYyBmdW5jdGlvbiBhcHBlbmRDU1MoJGZpbGUsJHBhdGg9JycpDQogew0KCWlmKGVtcHR5KCRwYXRoKSl7DQogCQkkdGhpcy0+Y3NzW109JHRoaXMtPmJhc2VVcmwoKS4iL2Nzcy8iLiRmaWxlOw0KIAl9DQogCWVsc2Ugew0KIAkJJHRoaXMtPmNzc1tdPSRwYXRoLiIvIi4kZmlsZTsNCiAJfQ0KIH0NCg==',
//       ),
//       'getCssFiles' => 
//       array (
//         'params' => 
//         array (
//         ),
//         'code' => 'IHB1YmxpYyBmdW5jdGlvbiBnZXRDc3NGaWxlcygpDQogew0KCSRjc3MgPSAkdGhpcy0+Y3NzOw0KCXJldHVybiAkY3NzOw0KIH0NCg==',
//       ),
//       'getJsFiles' => 
//       array (
//         'params' => 
//         array (
//         ),
//         'code' => 'cHVibGljIGZ1bmN0aW9uIGdldEpzRmlsZXMoKQ0Kew0KCSRqcyA9ICR0aGlzLT5qczsNCglyZXR1cm4gJGpzOw0KfQ0K',
//       ),
//       'view' => 
//       array (
//         'params' => 
//         array (
//         ),
//         'code' => 'IHB1YmxpYyBmdW5jdGlvbiB2aWV3KCkNCiB7DQogCWlmKCR0aGlzLT5jb250cm9sbGVyT2JqLT52aWV3UmVxdWlyZWQpDQogCXsNCgkgCSRob3N0PSRHTE9CQUxTWydob3N0J107DQoJIAkkcGF0aCA9ICRfU0VSVkVSWydET0NVTUVOVF9ST09UJ10uJGhvc3QuIi9tb2R1bGVzLyIuJEdMT0JBTFNbJ2ZvcmtvYmonXVsnbW9kdWxlJ10uIi92aWV3cy8iLiRHTE9CQUxTWydmb3Jrb2JqJ11bJ2NvbnRyb2xsZXInXS4iLyIuJEdMT0JBTFNbJ2ZvcmtvYmonXVsnYWN0aW9uJ10uIi5waHRtbCI7DQoJIAlpZihmaWxlX2V4aXN0cygkcGF0aCkpDQoJIAl7DQoJIAkJJHZpZXdPYmogPSBuZXcgVmlldygkdGhpcy0+Y29udHJvbGxlck9iaiwkcGF0aCk7DQoJIAkJJHRoaXMtPmNzcz0gYXJyYXlfbWVyZ2UoJHRoaXMtPmNzcywkdmlld09iai0+Z2V0Q3NzRmlsZXMoKSk7DQoJIAkJJHRoaXMtPmpzPSBhcnJheV9tZXJnZSgkdGhpcy0+anMsJHZpZXdPYmotPmdldEpzRmlsZXMoKSk7DQoJIAkvLwlwcmludF9yKCR0aGlzLT5jc3MpOw0KCSAJLy8JcHJpbnRfcigkdGhpcy0+anMpOw0KCSAJfQ0KCQllbHNlDQoJCXsNCiAgICAJCXRyaWdnZXJfZXJyb3IoIk1JU1NJTkdfVklFV19GSUxFIixFX1VTRVJfRVJST1IpOyAvLyBtaXNzaW5nIHZpZXcgZmlsZQ0KCQl9DQogCX0NCiAJZWxzZQ0KIAl7DQogCQl0cmlnZ2VyX2Vycm9yKCJJTlZBTElEX1ZJRVdfQUNDRVNTIixFX1VTRVJfRVJST1IpOyAvLyBBY2Nlc3MgdG8gdmlldyB3aGVyZWFzIHZpZXdSZXF1aXJlZCBpcyBzZXQgdG8gZmFsc2UgZnJvbSBBY3Rpb24gY2FsbC4NCiAJfQ0KIH0NCg==',
//       ),
//     ),
//   ),
//   'controller' => 
//   array (
//     'properties' => 
//     array (
//       0 => 'layoutRequired',
//       1 => 'layout',
//       2 => 'viewRequired',
//       3 => 'view',
//       4 => 'title',
//     ),
//     'methods' => 
//     array (
//       '__construct' => 
//       array (
//         'params' => 
//         array (
//         ),
//         'code' => 'CXB1YmxpYyBmdW5jdGlvbiBfX2NvbnN0cnVjdCgpDQoJew0KCQkkdmlldyA9IG5ldyBTdGRDbGFzczsNCgl9DQo=',
//       ),
//       'setLayout' => 
//       array (
//         'params' => 
//         array (
//         ),
//         'code' => 'CXB1YmxpYyBmdW5jdGlvbiBzZXRMYXlvdXQoKQ0KCXsNCgkJJGhvc3Q9JEdMT0JBTFNbJ2hvc3QnXTsNCgkJJG1vZHVsZT0gJEdMT0JBTFNbJ2ZvcmtvYmonXVsnbW9kdWxlJ107CQ0KCQkkbGF5b3V0ID1wYXJzZV9pbmlfZmlsZSgkX1NFUlZFUlsnRE9DVU1FTlRfUk9PVCddLiRob3N0LiIvQXBwL2FwcGxpY2F0aW9uLmluaSIpOw0KCQkkbGF5b3V0PWlzc2V0KCRsYXlvdXRbImxheW91dHMiXVskbW9kdWxlXSk/JGxheW91dFsibGF5b3V0cyJdWyRtb2R1bGVdOiJkZWZhdWx0IjsNCgkJJHRoaXMtPmxheW91dD0kbGF5b3V0Ow0KCX0NCg==',
//       ),
//       'post' => 
//       array (
//         'params' => 
//         array (
//           0 => 'key',
//         ),
//         'code' => 'CXB1YmxpYyBmdW5jdGlvbiBwb3N0KCRrZXk9IiIpDQoJew0KCQlpZighJGtleSkNCgkJew0KCQkJcmV0dXJuICRfUE9TVDsNCgkJfQ0KCQllbHNlDQoJCXsNCgkJCXJldHVybiBpc3NldCgkX1BPU1RbJGtleV0pPyRfUE9TVFska2V5XToiIjsNCgkJfQ0KCX0NCg==',
//       ),
//       'get' => 
//       array (
//         'params' => 
//         array (
//           0 => 'key',
//         ),
//         'code' => 'CXB1YmxpYyBmdW5jdGlvbiBnZXQoJGtleT0iIikNCgl7DQoJCSR1cmwgPSAkX0dFVFsncGFyYW1zJ107DQoNCgkJJGRhdGE9IGV4cGxvZGUoJy8nLCAkdXJsKTsNCgkJLy9wcmludF9yKCRkYXRhKTsNCgkJJHBhcmFtcz1hcnJheSgpOw0KCQlmb3IoJGk9MzskaSA8IGNvdW50KCRkYXRhKTskaSsrKQ0KCQl7DQoJCQlpZihpc3NldCgkZGF0YVskaSsxXSkpDQoJCQkkcGFyYW1zWyRkYXRhWyRpXV0gPSRkYXRhWysrJGldOyANCgkJfQ0KCQlpZighJGtleSkNCgkJew0KCQkJcmV0dXJuICRwYXJhbXM7DQoJCX0NCgkJZWxzZQ0KCQl7DQoJCQlpZihpc3NldCgkcGFyYW1zWyRrZXldKSkNCgkJCXsNCgkJCQlyZXR1cm4gJHBhcmFtc1ska2V5XTsNCgkJCX0NCgkJCWVsc2UNCgkJCXsNCgkJCQlyZXR1cm4gIiI7DQoJCQl9DQoJCX0NCgl9DQo=',
//       ),
//       'redirect' => 
//       array (
//         'params' => 
//         array (
//           0 => 'url',
//           1 => 'params',
//         ),
//         'code' => 'CXB1YmxpYyBmdW5jdGlvbiByZWRpcmVjdCgkdXJsLCRwYXJhbXM9YXJyYXkoKSkNCgl7DQoJCWlmKCFpc19zdHJpbmcoJHVybCkpDQoJCXsNCgkJCWlmKGdldF9jbGFzcygkdXJsKT09Ik1WQyIpDQoJCQl7DQoJCQkJJHVybD0kR0xPQkFMU1snaG9zdCddLiIvIi4kdXJsLT5tb2R1bGUuIi8iLiR1cmwtPmNvbnRyb2xsZXIuIi8iLiR1cmwtPmFjdGlvbjsNCg0KCQkJfQ0KCQl9DQoJCWlmKGNvdW50KCRwYXJhbXMpPjApDQoJCXsNCgkJCSR1cmwuPSIvIjsNCgkJCWZvcmVhY2ggKCRwYXJhbXMgYXMgJGtleSA9PiAkdmFsdWUpIHsNCgkJCQkkdXJsIC49JGtleS4iLyIuJHZhbHVlLiIvIjsNCgkJCX0NCgkJCSR1cmw9c3Vic3RyKCR1cmwsIDAsc3RybGVuKCR1cmwpLTEpOw0KCQkJDQoJCX0NCgkJLy9lY2hvICR1cmw7DQoJCWhlYWRlcignTG9jYXRpb246ICcuJHVybCk7DQoJfQ0K',
//       ),
//       'appBase' => 
//       array (
//         'params' => 
//         array (
//         ),
//         'code' => 'CSBwdWJsaWMgZnVuY3Rpb24gYXBwQmFzZSgpDQoJIHsNCgkgCSRzZXJ2ZXI9JF9TRVJWRVJbJ0hUVFBfSE9TVCddOw0KCSAJJHVybD0gJEdMT0JBTFNbJ2hvc3QnXTsNCgkgCXJldHVybiAkdXJsOw0KCSB9DQo=',
//       ),
//     ),
//   ),
//   'view' => 
//   array (
//     'properties' => 
//     array (
//       0 => 'view',
//       1 => 'js',
//       2 => 'css',
//       3 => 'controllerObj',
//     ),
//     'methods' => 
//     array (
//       '__construct' => 
//       array (
//         'params' => 
//         array (
//           0 => 'controllerObj',
//           1 => 'path',
//           2 => 'isPartial',
//         ),
//         'code' => 'CWZ1bmN0aW9uIF9fY29uc3RydWN0KCRjb250cm9sbGVyT2JqLCRwYXRoLCRpc1BhcnRpYWw9MCkNCgl7DQoJCWlmKCRjb250cm9sbGVyT2JqLT5sYXlvdXRSZXF1aXJlZD09ZmFsc2UgJiYgJGlzUGFydGlhbD09MCkNCgkJew0KCQkJJHRoaXMtPmNzcz1hcnJheSgpOw0KCQkJJHRoaXMtPmpzPWFycmF5KCk7DQoJCQkkdGhpcy0+Y29udHJvbGxlck9iaj0kY29udHJvbGxlck9iajsNCgkJCSR0aGlzLT52aWV3PSRjb250cm9sbGVyT2JqLT52aWV3Ow0KCQkJb2Jfc3RhcnQoKTsNCg0KCQkJJGNvbnQgPSBpbmNsdWRlICRwYXRoOw0KCQkJJGJ1ZmZlciA9b2JfZ2V0X2NsZWFuKCk7DQoJCQkkaHRtbCA9ICI8IURPQ1RZUEUgaHRtbD5cbiI7DQoJCQkkaHRtbCAuPSI8aGVhZD5cbiI7DQoJCQkkaHRtbCAuPSI8dGl0bGU+Ii4kY29udHJvbGxlck9iai0+dGl0bGUuIjwvdGl0bGU+XG4iOw0KCQkJJGh0bWwgLj0kdGhpcy0+aGVhZEZpbGVzKCR0aGlzLT5jc3MsJHRoaXMtPmpzKS4iXG4iOw0KCQkJJGh0bWwgLj0iPC9oZWFkPlxuPGJvZHk+XG4iOw0KCQkJZWNobyAkaHRtbDsNCgkJCWVjaG8gJGJ1ZmZlcjsNCgkJCWVjaG8gIjwvYm9keT5cbjwvaHRtbD4iOw0KCQl9DQoJCWVsc2UNCgkJew0KCQkJJHRoaXMtPmNzcz1hcnJheSgpOw0KCQkJJHRoaXMtPmpzPWFycmF5KCk7DQoJCQkkdGhpcy0+Y29udHJvbGxlck9iaj0kY29udHJvbGxlck9iajsNCgkJCSR0aGlzLT52aWV3PSRjb250cm9sbGVyT2JqLT52aWV3Ow0KCQkJb2Jfc3RhcnQoKTsNCgkJCSRjb250ID0gaW5jbHVkZSAkcGF0aDsNCgkJCSRidWZmZXIgPW9iX2dldF9jbGVhbigpOw0KCQkJLy9wcmludF9yKCR0aGlzLT5jc3MpOw0KCQkJZWNobyAkYnVmZmVyOw0KCQl9DQoJCQ0KCX0NCg==',
//       ),
//       'headFiles' => 
//       array (
//         'params' => 
//         array (
//           0 => 'cssArr',
//           1 => 'jsArr',
//         ),
//         'code' => 'IHB1YmxpYyBmdW5jdGlvbiBoZWFkRmlsZXMoJGNzc0FyciwkanNBcnIpDQogew0KIAkvL3ByaW50X3IoJHRoaXMtPmNzcyk7DQogCSRzdHJpbmc9IiI7DQogCWZvcmVhY2ggKGFycmF5X3VuaXF1ZSgkanNBcnIpIGFzICRqcykgew0KIAkJJHN0cmluZyAuPSI8c2NyaXB0IHR5cGU9J3RleHQvamF2YXNjcmlwdCcgc3JjPSciLiRqcy4iJz48L3NjcmlwdD5cbiI7DQogCX0NCiAJZm9yZWFjaCAoYXJyYXlfdW5pcXVlKCRjc3NBcnIpIGFzICRjc3MpIHsNCiAJCSRzdHJpbmcgLj0iPGxpbmsgcmVsPSdzdHlsZXNoZWV0JyB0eXBlPSd0ZXh0L2NzcycgaHJlZj0nIi4kY3NzLiInPlxuIjsNCiAJfQ0KIAlyZXR1cm4gJHN0cmluZzsNCiB9DQo=',
//       ),
//       'partial' => 
//       array (
//         'params' => 
//         array (
//           0 => 'file',
//         ),
//         'code' => 'CXB1YmxpYyBmdW5jdGlvbiBwYXJ0aWFsKCRmaWxlKQ0KCXsNCgkJJGhvc3Q9JEdMT0JBTFNbJ2hvc3QnXTsNCg0KCQlpZihmaWxlX2V4aXN0cygkX1NFUlZFUlsnRE9DVU1FTlRfUk9PVCddLiRob3N0LiIvbW9kdWxlcy8iLiRHTE9CQUxTWydmb3Jrb2JqJ11bJ21vZHVsZSddLiIvdmlld3MvIi4kR0xPQkFMU1snZm9ya29iaiddWydjb250cm9sbGVyJ10uIi8iLiRmaWxlLiIucGh0bWwiKSkNCgkJew0KCQkJDQoJCQkkcGF0aD0kX1NFUlZFUlsnRE9DVU1FTlRfUk9PVCddLiRob3N0LiIvbW9kdWxlcy8iLiRHTE9CQUxTWydmb3Jrb2JqJ11bJ21vZHVsZSddLiIvdmlld3MvIi4kR0xPQkFMU1snZm9ya29iaiddWydjb250cm9sbGVyJ10uIi8iLiRmaWxlLiIucGh0bWwiOw0KCQkJLy9jcmVhdGUgdmlldyANCgkJCS8vZWNobyAkcGF0aDsNCgkJCSRwYXJ0aWFsVmlldyA9IG5ldyBWaWV3KCR0aGlzLT5jb250cm9sbGVyT2JqLCRwYXRoLDEpOwkgICAgDQoJCQkkdGhpcy0+Y3NzPWFycmF5X21lcmdlKCR0aGlzLT5jc3MsJHBhcnRpYWxWaWV3LT5jc3MpOw0KCQkJJHRoaXMtPmpzPWFycmF5X21lcmdlKCR0aGlzLT5qcywkcGFydGlhbFZpZXctPmpzKTsNCg0KCQl9DQoJCWVsc2UNCgkJew0KICAgIAkJJEdMT0JBTFNbJ3RyYWNLX2luZm8nXVsncGFydGlhbCddPSRmaWxlOw0KCQkJJEdMT0JBTFNbJ3RyYWNLX2luZm8nXVsnc291cmNlJ109JEdMT0JBTFNbJ2ZvcmtvYmonXVsnYWN0aW9uJ10uIi5waHRtbCBWaWV3IjsNCgkJCXRyaWdnZXJfZXJyb3IoIk1JU1NJTkdfUEFSVElBTF9WSUVXX0ZJTEUiLEVfVVNFUl9FUlJPUik7IC8vIG1pc3Npbmcgdmlldw0KCQl9DQoJCQ0KDQoJfQ0K',
//       ),
//       'getCssFiles' => 
//       array (
//         'params' => 
//         array (
//         ),
//         'code' => 'CXB1YmxpYyBmdW5jdGlvbiBnZXRDc3NGaWxlcygpDQoJew0KCQkkY3NzID0gJHRoaXMtPmNzczsNCgkJcmV0dXJuICRjc3M7DQoJfQ0K',
//       ),
//       'getJsFiles' => 
//       array (
//         'params' => 
//         array (
//         ),
//         'code' => 'CXB1YmxpYyBmdW5jdGlvbiBnZXRKc0ZpbGVzKCkNCgl7DQoJCSRqcyA9ICR0aGlzLT5qczsNCgkJcmV0dXJuICRqczsNCgl9DQo=',
//       ),
//       'appendJS' => 
//       array (
//         'params' => 
//         array (
//           0 => 'file',
//           1 => 'path',
//         ),
//         'code' => 'CSBwdWJsaWMgZnVuY3Rpb24gYXBwZW5kSlMoJGZpbGUsJHBhdGg9JycpDQoJIHsNCgkgCWlmKGVtcHR5KCRwYXRoKSl7DQoJIAkJJHRoaXMtPmpzW109JHRoaXMtPmJhc2VVcmwoKS4iL2pzLyIuJGZpbGU7DQoJIAl9DQoJIAllbHNlIHsNCgkgCQkkdGhpcy0+anNbXT0kcGF0aC4iLyIuJGZpbGU7DQoJIAl9DQoJCQ0KCSB9DQo=',
//       ),
//       'appendCSS' => 
//       array (
//         'params' => 
//         array (
//           0 => 'file',
//           1 => 'path',
//         ),
//         'code' => 'CSBwdWJsaWMgZnVuY3Rpb24gYXBwZW5kQ1NTKCRmaWxlLCRwYXRoPScnKQ0KCSB7DQoJCWlmKGVtcHR5KCRwYXRoKSl7DQoJIAkJJHRoaXMtPmNzc1tdPSR0aGlzLT5iYXNlVXJsKCkuIi9jc3MvIi4kZmlsZTsNCgkgCX0NCgkgCWVsc2Ugew0KCSAJCSR0aGlzLT5jc3NbXT0kcGF0aC4iLyIuJGZpbGU7DQoJIAl9DQoJIH0NCg==',
//       ),
//       'baseUrl' => 
//       array (
//         'params' => 
//         array (
//         ),
//         'code' => 'CXB1YmxpYyBmdW5jdGlvbiBiYXNlVXJsKCkNCiAJew0KCSAJJHNlcnZlcj0kX1NFUlZFUlsnSFRUUF9IT1NUJ107DQoJIAkkdXJsPSAkR0xPQkFMU1snaG9zdCddLiIvc2l0ZSI7DQoJIAlyZXR1cm4gJHVybDsNCiAJfQ0K',
//       ),
//       'appBase' => 
//       array (
//         'params' => 
//         array (
//         ),
//         'code' => 'IAlwdWJsaWMgZnVuY3Rpb24gYXBwQmFzZSgpDQoJew0KCSAJJHNlcnZlcj0kX1NFUlZFUlsnSFRUUF9IT1NUJ107DQoJIAkkdXJsPSAkR0xPQkFMU1snaG9zdCddOw0KCSAJcmV0dXJuICR1cmw7DQoJfQ0K',
//       ),
//       'post' => 
//       array (
//         'params' => 
//         array (
//           0 => 'key',
//         ),
//         'code' => 'CXB1YmxpYyBmdW5jdGlvbiBwb3N0KCRrZXk9IiIpDQoJew0KCQlpZighJGtleSkNCgkJew0KCQkJcmV0dXJuICRfUE9TVDsNCgkJfQ0KCQllbHNlDQoJCXsNCgkJCXJldHVybiBpc3NldCgkX1BPU1RbJGtleV0pPyRfUE9TVFska2V5XToiIjsNCgkJfQ0KCX0NCg==',
//       ),
//       'get' => 
//       array (
//         'params' => 
//         array (
//           0 => 'key',
//         ),
//         'code' => 'CXB1YmxpYyBmdW5jdGlvbiBnZXQoJGtleT0iIikNCgl7DQoJCSR1cmwgPSAkX0dFVFsncGFyYW1zJ107DQoNCgkJJGRhdGE9IGV4cGxvZGUoJy8nLCAkdXJsKTsNCgkJLy9wcmludF9yKCRkYXRhKTsNCgkJJHBhcmFtcz1hcnJheSgpOw0KCQlmb3IoJGk9MzskaSA8IGNvdW50KCRkYXRhKTskaSsrKQ0KCQl7DQoJCQlpZihpc3NldCgkZGF0YVskaSsxXSkpDQoJCQkkcGFyYW1zWyRkYXRhWyRpXV0gPSRkYXRhWysrJGldOyANCgkJfQ0KCQlpZighJGtleSkNCgkJew0KCQkJcmV0dXJuICRwYXJhbXM7DQoJCX0NCgkJZWxzZQ0KCQl7DQoJCQlpZihpc3NldCgkcGFyYW1zWyRrZXldKSkNCgkJCXsNCgkJCQlyZXR1cm4gJHBhcmFtc1ska2V5XTsNCgkJCX0NCgkJCWVsc2UNCgkJCXsNCgkJCQlyZXR1cm4gIiI7DQoJCQl9DQoJCX0NCgl9DQo=',
//       ),
//     ),
//   ),
//   'pathprovider' => 
//   array (
//     'properties' => 
//     array (
//       0 => 'forkObj',
//       1 => 'errorObj',
//     ),
//     'methods' => 
//     array (
//       '__construct' => 
//       array (
//         'params' => 
//         array (
//         ),
//         'code' => 'CXB1YmxpYyBmdW5jdGlvbiBfX2NvbnN0cnVjdCgpCgl7CgkJJGFwcE9iaiA9IG5ldyBhcHBDb25maWcoKTsKCQkkR0xPQkFMU1snY29uZmlnJ109JGFwcE9iai0+Z2V0KCk7CgkJaWYoIWRlZmluZWQoJ0FQUF9OQU1FJykpCgkJZGVmaW5lKCdBUFBfTkFNRScsICRHTE9CQUxTWydjb25maWcnXVsnYXBwbGljYXRpb24nXSk7Cgl9Cg==',
//       ),
//       'createHeader' => 
//       array (
//         'params' => 
//         array (
//           0 => 'title',
//         ),
//         'code' => 'CXB1YmxpYyBmdW5jdGlvbiBjcmVhdGVIZWFkZXIoJHRpdGxlKQoJewoJIAkkaGVhZGVyID0iPGhlYWQ+IjsKCSAJJGhlYWRlciAuPSI8dGl0bGU+Ii4kdGl0bGUuIjwvdGl0bGU+IjsKCSAJJGhlYWRlciAuPSI8L2hlYWQ+IjsKCgkgCXJldHVybiAkaGVhZGVyOwoJfQo=',
//       ),
//       'getPath' => 
//       array (
//         'params' => 
//         array (
//           0 => 'url',
//           1 => 'host',
//         ),
//         'code' => 'CXB1YmxpYyBmdW5jdGlvbiBnZXRQYXRoKCR1cmwsJGhvc3QpCgl7CgoJCUBzZXNzaW9uX3N0YXJ0KCk7CgkJc2V0X2Vycm9yX2hhbmRsZXIoJ3BhcnNlX2Vycm9yJyxFX1VTRVJfRVJST1IpOwoJCS8vIENvbnNpZGVyYXRpb24gb2YgZmluZSByZXF1ZXN0cyBvbmx5CgkJJGFic1VybCA9ICR1cmw7CgkJJGluZGV4ID0gc3RycG9zKCR1cmwsIj8iKTsKCQlpZigkaW5kZXg+MCkKCQl7CgkJCSRnZXRBcnJheSA9IHN1YnN0cigkdXJsLCRpbmRleCsxKTsKCQkJJGdldEFycmF5ID0gc3RyX3JlcGxhY2UoIj0iLCAiLyIsICRnZXRBcnJheSk7CgkJCSRnZXRBcnJheSA9IHN0cl9yZXBsYWNlKCImIiwgIi8iLCAkZ2V0QXJyYXkpOwoJCQkkX0dFVFsncGFyYW1zJ109Ik1PRC9DT04vQUNULyIuJGdldEFycmF5OwoJCQkvL2VjaG8gJGdldEFycmF5OwoJCQkkYWJzVXJsID0gJHVybDsKCQkJJHVybCA9IHN1YnN0cigkdXJsLDAsJGluZGV4KTsKCQl9CgkJZWxzZQoJCXsKCQkJLy9lY2hvICRob3N0LiI8YnIvPiIuJHVybDsKCQkJJGdldEFyciA9IGV4cGxvZGUoIi8iLCBsdHJpbShzdHJfcmVwbGFjZShzdHJ0b2xvd2VyKCRob3N0KSwgIiIsIHN0cnRvbG93ZXIoJHVybCkpLCcvJykpOwoJCQkKCQkJJF9HRVRbJ3BhcmFtcyddID0gaW1wbG9kZSgiLyIsICRnZXRBcnIpOwoJCQkvKmlmKGNvdW50KCRnZXRBcnIpPjIpewoJCQkJZm9yICgkaWk9MzsgJGlpIDwgY291bnQoJGdldEFycik7ICRpaSsyKSB7IAoJCQkJCSMgY29kZS4uLgoJCQkJCS8vJF9HRVRbJGdldEFyclskaWldXSA9IGlzc2V0KCRnZXRBcnJbJGlpKzFdKT8kZ2V0QXJyWyRpaSsxXToiIjsKCQkJCX0KCQkJfSovCgoJCX0KCQkKCgkJLyplbHNlIAoJCSRfR0VUWydwYXJhbXMnXT0gIiI7Ki8KCQkvL2VjaG8gJEdMT0JBTFNbJ2hvc3QnXTsKCQkkY291bnQgPSBjb3VudChleHBsb2RlKCcvJywkR0xPQkFMU1snaG9zdCddKSk7CgkJLy9lY2hvICRjb3VudDsKCQkkdXJsID0gbHRyaW0oJHVybCwnLycpOwoKCQkvKioKCQkgKglDaGVjayBmb3IgbWFnaWMgcGF0aHMgJiByZXJvdXRpbmcKCQkgKi8KCgkJJHJvdXRlciA9IGluY2x1ZGVfb25jZSAicm91dGVzLnBocCI7IC8qIGdldCBtYWdpYyBwYXRoIGFycmF5ICovCgkJJG1hcEluZGV4ID0gc3RyX3JlcGxhY2UobHRyaW0oJEdMT0JBTFNbJ2hvc3QnXSwnLycpLCcnLCRhYnNVcmwpOwoJCS8vZWNobyAkYWJzVXJsOwoJCSRtYXBJbmRleCA9IHN0cl9yZXBsYWNlKCI/IiwgIi8iLCAkbWFwSW5kZXgpOwoJCSRtYXBJbmRleCA9IHN0cl9yZXBsYWNlKCImIiwgIi8iLCAkbWFwSW5kZXgpOwoJCSRtYXBJbmRleCA9IHN0cl9yZXBsYWNlKCI9IiwgIi8iLCAkbWFwSW5kZXgpOwoJCS8vZWNobyAkbWFwSW5kZXg7ZGllOwoJCS8qKgoJCSogQ2hlY2tpbmcgZm9yIGEgZXhpc3RpbmcgbWFwcGluZyBpbiBtYWdpYyByb3V0ZXMKCQkqLwoJCS8vcHJpbnRfcigkcm91dGVyKTtkaWU7CgoJCSRyb3V0ZXIgPSAoYXJyYXkpJHJvdXRlcjsKCQlmb3JlYWNoICgkcm91dGVyIGFzICRrZXkgPT4gJHZhbHVlKSB7CgkJCSRyZWcgPSAgJHRoaXMtPmdlbmVyYXRlUmVnZXgoJGtleSk7CgkJCS8qZWNobyAicmVnZXggOiAiLiRyZWc7ICAgcmVpbml0aWFsaXplIHBhdGggbWFwcGluZy4gCgkJCWRpZSgpOyovCgkJCWlmKHByZWdfbWF0Y2goJHJlZywkbWFwSW5kZXgsJHJlZ091dCkpCgkJCXsKCQkJCWZvcmVhY2ggKCRyZWdPdXQgYXMgJHNlZ21lbnRLZXkgPT4gJHNlZ21lbnRzVmFsKSB7CgkJCQkJJHZhbHVlID0gc3RyX3JlcGxhY2UoInsiLnN0cl9yZXBsYWNlKCJfIiwgIjoiLCAkc2VnbWVudEtleSkuIn0iLCAkc2VnbWVudHNWYWwsICR2YWx1ZSk7CgkJCQl9CgkJCQkvL2VjaG8gInZhbHVwIDogIi4kdmFsdWU7CgoJCQkJJHBhdGhPYmogPSBuZXcgcGF0aFByb3ZpZGVyKCk7CgkJCQkkcGF0aE9iai0+Z2V0UGF0aCgiLyIuJEdMT0JBTFNbJ2hvc3QnXS4kdmFsdWUsJEdMT0JBTFNbJ2hvc3QnXSk7IAoJCQkJLy9lY2hvICR2YWx1ZTsKCQkJCWRpZTsKCQkJfQoJCQllbHNlCgkJCXsKCQkJCSRyZWcgPSAgJHRoaXMtPmdlbmVyYXRlUmVnZXgoJHZhbHVlKTsKCQkJCS8qZWNobyAib286Ii4kcmVnOwoJCQkJZWNobyAibWk6ICIuJG1hcEluZGV4OyovCgkJCQlpZihwcmVnX21hdGNoKCRyZWcsJG1hcEluZGV4LCRyZWdPdXQpKQoJCQkJewoJCQkJCS8vZWNobyAiOmtrIjtkaWU7CgkJCQkJZm9yZWFjaCAoJHJlZ091dCBhcyAkc2VnbWVudEtleSA9PiAkc2VnbWVudHNWYWwpIHsKCQkJCQkJJGtleSA9IHN0cl9yZXBsYWNlKCJ7Ii5zdHJfcmVwbGFjZSgiXyIsICI6IiwgJHNlZ21lbnRLZXkpLiJ9IiwgJHNlZ21lbnRzVmFsLCAka2V5KTsKCQkJCQl9CgkJCQkJaGVhZGVyKCJMb2NhdGlvbjogIi4kR0xPQkFMU1snaG9zdCddLiRrZXkpOwoJCQkJfQoKCgkJCX0KCgkJfQoJCS8qaWYoaXNzZXQoJHJvdXRlclskbWFwSW5kZXhdKSkKCQl7CgkJCSRwYXRoT2JqID0gbmV3IHBhdGhQcm92aWRlcigpOwoJCQkkcGF0aE9iai0+Z2V0UGF0aCgiLyIuJEdMT0JBTFNbJ2hvc3QnXS4kcm91dGVyWyRtYXBJbmRleF0sJEdMT0JBTFNbJ2hvc3QnXSk7IAoJCQkKCQl9CgkJZWxzZSovCgkJewoJCQkvL2VjaG8gJHVybDsKCQkJLy8kdXJsID0gc3RyX3JlcGxhY2UoJEdMT0JBTFNbJ2hvc3QnXSwgJycsICR1cmwpOwoJLy8JCSR1cmwgPSBzdHJfcmVwbGFjZShzdHJ0b2xvd2VyKCRHTE9CQUxTWydob3N0J10pLCAnJyxzdHJ0b2xvd2VyKGx0cmltKCR1cmwsIi8iKSkgKSA7CgkJCS8vZWNobyAkdXJsOwoJCQkkcGF0aF9hcnI9IGV4cGxvZGUoIi8iLCR1cmwpOwoJCQkvL2VjaG8gJHVybDtkaWU7CgkJLy8JcHJpbnRfcigkcGF0aF9hcnIpOwoJCQkvL2lmKCFlbXB0eSgkR0xPQkFMU1snaG9zdCddKSkKCQkJewoJCQkJJGNvdW50LS07CgkJCX0KCQkJLy9lY2hvICRjb3VudDsKCQkJLy8gY2hlY2sgZm9yIGluc3RhbmNlIGluc3RhbGxhdGlvbgoJCQkvKmlmKCFpc19maWxlKCRfU0VSVkVSWydET0NVTUVOVF9ST09UJ10uJGhvc3QuJy9jb25maWcucGhwJykpCgkJCXsKCQkJCQoJCQl9Ki8KCQkJJHBhdGhPYmo9IGFycmF5KCk7CgkJCSRwYXRoT2JqWydob3N0J109JEdMT0JBTFNbJ2hvc3QnXTsKCQkJJHBhdGhPYmpbJ21vZHVsZSddPWlzc2V0KCRwYXRoX2FyclskY291bnRdKSYmJHBhdGhfYXJyWyRjb3VudF0hPSIiPyRwYXRoX2FyclskY291bnRdOiJkZWZhdWx0IjsKCQkJJHBhdGhPYmpbJ2NvbnRyb2xsZXInXT1pc3NldCgkcGF0aF9hcnJbJGNvdW50KzFdKSYmJHBhdGhfYXJyWyRjb3VudCsxXSE9IiI/JHBhdGhfYXJyWyRjb3VudCsxXToiaW5kZXgiOwoJCQkkcGF0aE9ialsnYWN0aW9uJ109aXNzZXQoJHBhdGhfYXJyWyRjb3VudCsyXSkmJiRwYXRoX2FyclskY291bnQrMl0hPSIiPyRwYXRoX2FyclskY291bnQrMl06ImluZGV4IjsKCQkJLy9wcmludF9yKCRwYXRoT2JqKTsKCQkJJGluZm8gPSBhcnJheSgibW9kdWxlIj0+JHBhdGhPYmpbJ21vZHVsZSddLCJjb250cm9sbGVyIj0+JHBhdGhPYmpbJ2NvbnRyb2xsZXInXSwiYWN0aW9uIj0+JHBhdGhPYmpbJ2FjdGlvbiddKTsKCQkJJEdMT0JBTFNbJ3RyYWNLX2luZm8nXT0kaW5mbzsKCQkJLy9lY2hvICRfU0VSVkVSWydET0NVTUVOVF9ST09UJ10uJGhvc3QuIi9tb2R1bGVzLyIuJHBhdGhPYmpbJ21vZHVsZSddO2RpZSgpOwoJICAgIAlpZihpc19kaXIoJF9TRVJWRVJbJ0RPQ1VNRU5UX1JPT1QnXS4kaG9zdC4iL21vZHVsZXMvIi4kcGF0aE9ialsnbW9kdWxlJ10pKQoJCQl7CgkgICAgCQlpZihmaWxlX2V4aXN0cygkX1NFUlZFUlsnRE9DVU1FTlRfUk9PVCddLiRob3N0LiIvbW9kdWxlcy8iLiRwYXRoT2JqWydtb2R1bGUnXS4iL2NvbnRyb2xsZXJzLyIuJHBhdGhPYmpbJ2NvbnRyb2xsZXInXS4iQ29udHJvbGxlci5waHAiKSkKCQkJCXsKCQkJCQkKCQkgICAgCQlpbmNsdWRlICRfU0VSVkVSWydET0NVTUVOVF9ST09UJ10uJGhvc3QuIi9tb2R1bGVzLyIuJHBhdGhPYmpbJ21vZHVsZSddLiIvY29udHJvbGxlcnMvIi4kcGF0aE9ialsnY29udHJvbGxlciddLiJDb250cm9sbGVyLnBocCI7CgkJCSAgICAJLy9lY2hvICJDb250cm9sbGVyIGV4aXN0cyI7CgkgICAgCSAgICAJaWYgKGNsYXNzX2V4aXN0cygkcGF0aE9ialsnbW9kdWxlJ10uJ18nLiRwYXRoT2JqWydjb250cm9sbGVyJ10uJ0NvbnRyb2xsZXInKSkKCQkJICAgIAl7CgkJCSAgICAJCSRjb250cm9sbGVyQ2xhc3M9JHBhdGhPYmpbJ21vZHVsZSddLidfJy4kcGF0aE9ialsnY29udHJvbGxlciddLidDb250cm9sbGVyJzsKCQkJICAgIAkJJEdMT0JBTFNbJ2ZvcmtvYmonXT1hcnJheSgpOwoJCQkgICAgCQkkR0xPQkFMU1snZm9ya29iaiddWydtb2R1bGUnXT0kcGF0aE9ialsnbW9kdWxlJ107CgkJCSAgICAJCSRHTE9CQUxTWydmb3Jrb2JqJ11bJ2NvbnRyb2xsZXInXT0kcGF0aE9ialsnY29udHJvbGxlciddOwoJCQkgICAgCQkkR0xPQkFMU1snZm9ya29iaiddWydhY3Rpb24nXT0kcGF0aE9ialsnYWN0aW9uJ107CgkJCSAgICAJCSRHTE9CQUxTWydob3N0J109JGhvc3Q7CgkJCSAgICAJCS8vcHJpbnRfcigkR0xPQkFMU1snZm9ya29iaiddKTtkaWUoKTsKCQkJICAgIAkJaWYoIW1ldGhvZF9leGlzdHMoJGNvbnRyb2xsZXJDbGFzcywkcGF0aE9ialsnYWN0aW9uJ10uIkFjdGlvbiIgKSkKCQkJICAgIAkJewoJCSAgICAJCQkJLyokZXJyb3JPYmo9IG5ldyBFeGNlcHRpb25zKCJVTkRFRklORURfQUNUSU9OX0VYQ0VQVElPTiIsJGluZm8pOwoJCQkJCQkJcmV0dXJuICRlcnJvck9iai0+dGhyb3dFeGNlcHRpb24oKTsqLwoJCQkJCQkJdHJpZ2dlcl9lcnJvcigiVU5ERUZJTkVEX0FDVElPTl9FWENFUFRJT04iLEVfVVNFUl9FUlJPUik7IC8vQWN0aW9uIFVuZGVmaW5lZAoJCQkgICAgCQl9CgkJCSAgICAJCSRsYXlvdXQgPXBhcnNlX2luaV9maWxlKCRfU0VSVkVSWydET0NVTUVOVF9ST09UJ10uJGhvc3QuIi9BcHAvYXBwbGljYXRpb24uaW5pIik7CgkJCSAgICAJCQoJCQkgICAgCQkkbGF5b3V0PWlzc2V0KCRsYXlvdXRbImxheW91dHMiXVskcGF0aE9ialsnbW9kdWxlJ11dKT8kbGF5b3V0WyJsYXlvdXRzIl1bJHBhdGhPYmpbJ21vZHVsZSddXToiZGVmYXVsdCI7CgkJCSAgICAJCQoJCQkgICAgCQkkY29udHJvbGxlck9iaiA9IG5ldyAkY29udHJvbGxlckNsYXNzKCk7CgkJCSAgICAJCSRjb250cm9sbGVyT2JqLT5zZXRMYXlvdXQoKTsgLy8gSW1wb3J0YW50IHRvIGNhbGwgdG8gcmVhZCBhcHBsaWNhdGlvbi5pbmkgZm9yIGxheW91dCBvZiB0aGF0IG1vZHVsZQoJCQkgICAgCQkkYWN0aW9uPSRwYXRoT2JqWydhY3Rpb24nXS4iQWN0aW9uIjsKCQkJICAgIAkJCgkJCSAgICAJCS8vaWYoJHBhdGhPYmpbJ21vZHVsZSddPT0id2Vic2VydmljZSIpCgkJCSAgICAJCXsKCQkJICAgIAkJCS8vcHJpbnRfcigkX1BPU1QpO2RpZTsKCQkJICAgIAkJCSR3ZWJzZXJ2aWNlID0gbmV3IHdlYnNlcnZpY2UoKTsKCQkJICAgIAkJCSRyID0gbmV3IFJlZmxlY3Rpb25NZXRob2QoJHBhdGhPYmpbJ21vZHVsZSddLiJfIi4kcGF0aE9ialsnY29udHJvbGxlciddLiJDb250cm9sbGVyIiwgJHBhdGhPYmpbJ2FjdGlvbiddLiJBY3Rpb24iKTsKCSAgICAgICAgICAgICAgICAJCSRwYXJhbXMgPSAkci0+Z2V0UGFyYW1ldGVycygpOwoJICAgICAgICAgICAgICAgIAkJJHN0ckFyciA9YXJyYXkoKTsKCSAgICAgICAgICAgICAgICAJCWZvcmVhY2ggKCRwYXJhbXMgYXMgJHBhcmFtKSB7CgkgICAgICAgICAgICAgICAgCQkJJHN0ckFycltdPSInIi4kX1BPU1RbJHBhcmFtLT5nZXROYW1lKCldLiInIjsKCSAgICAgICAgICAgICAgICAJCX0KCSAgICAgICAgICAgICAgICAJCSRzdHI9aW1wbG9kZSgiLCIsICRzdHJBcnIpOwoJICAgICAgICAgICAgICAgIAkJJHN0ciA9ICckY29udHJvbGxlck9iai0+JGFjdGlvbignLiRzdHIuIik7IjsKCSAgICAgICAgICAgICAgICAJCWV2YWwoJHN0cik7CgkJCSAgICAJCQkvLyRjb250cm9sbGVyT2JqLT4kYWN0aW9uKCk7CgkJCSAgICAJCX0KCQkJICAgIAkJLyplbHNlCgkJCSAgICAJCXsKCQkJICAgIAkJCSRjb250cm9sbGVyT2JqLT4kYWN0aW9uKCk7CgkJCSAgICAJCX0qLwoJCQkgICAgCQlpZigkY29udHJvbGxlck9iai0+bGF5b3V0UmVxdWlyZWQpCgkJCSAgICAJCXsKCQkJICAgIAkJCSRsYXlvdXQ9JGNvbnRyb2xsZXJPYmotPmxheW91dDsKCQkJICAgIAkJCS8vZWNobyAkbGF5b3V0O2RpZTsKCQkJICAgIAkJCQoJCSAgICAJCQkJaWYoZmlsZV9leGlzdHMoJF9TRVJWRVJbJ0RPQ1VNRU5UX1JPT1QnXS4kaG9zdC4iL2xheW91dHMvIi4kbGF5b3V0LiIucGh0bWwiKSkKCQkJICAgIAkJCXsKCQkJICAgIAkJCQkKCQkJICAgIAkJCQkkcGF0aD0kX1NFUlZFUlsnRE9DVU1FTlRfUk9PVCddLiRob3N0LiIvbGF5b3V0cy8iLiRsYXlvdXQuIi5waHRtbCI7CgkJCSAgICAJCQkJLy9jcmVhdGUgbGF5b3V0IAoJCQkgICAgCQkJCSRsYXlvdXRPYmogPSBuZXcgTGF5b3V0KCRjb250cm9sbGVyT2JqLCRwYXRoKTsJCSAgICAJCQkKCQkJICAgIAkJCX0KCQkJICAgIAkJCWVsc2UKCQkJICAgIAkJCXsKCQkJCQkgICAgCQkvKiRlcnJvck9iaj0gbmV3IEV4Y2VwdGlvbnMoIjEwMDUiLCRsYXlvdXQpOwoJCQkgICAgCQkJCXJldHVybiAkZXJyb3JPYmotPnRocm93RXhjZXB0aW9uKCk7Ly8gbWlzc2luZyBsYXlvdXQqLwoJCQkgICAgCQkJCSRHTE9CQUxTWydlcnJvcmRhdGEnXVsnbGF5b3V0J109JGxheW91dDsKCQkJICAgIAkJCQl0cmlnZ2VyX2Vycm9yKCJNSVNTSU5HX0xBWU9VVF9GSUxFIixFX1VTRVJfRVJST1IpOwoKCQkJICAgIAkJCX0KCQkJICAgIAkJfQoJCQkgICAgCQllbHNlCgkJCSAgICAJCXsKCgkJCQkgICAgCQlpZigkY29udHJvbGxlck9iai0+dmlld1JlcXVpcmVkKQoJCQkJICAgIAkJewoKCQkJCSAgICAJCQlpZihmaWxlX2V4aXN0cygkX1NFUlZFUlsnRE9DVU1FTlRfUk9PVCddLiRob3N0LiIvbW9kdWxlcy8iLiRwYXRoT2JqWydtb2R1bGUnXS4iL3ZpZXdzLyIuJHBhdGhPYmpbJ2NvbnRyb2xsZXInXS4iLyIuJHBhdGhPYmpbJ2FjdGlvbiddLiIucGh0bWwiKSkKCQkJCSAgICAJCQl7CgkJCQkgICAgCQkJCQoJCQkJICAgIAkJCQkkcGF0aD0kX1NFUlZFUlsnRE9DVU1FTlRfUk9PVCddLiRob3N0LiIvbW9kdWxlcy8iLiRwYXRoT2JqWydtb2R1bGUnXS4iL3ZpZXdzLyIuJHBhdGhPYmpbJ2NvbnRyb2xsZXInXS4iLyIuJHBhdGhPYmpbJ2FjdGlvbiddLiIucGh0bWwiOwoJCQkJICAgIAkJCQkvL2NyZWF0ZSB2aWV3IAoJCQkJICAgIAkJCQkkdmlld09iaiA9IG5ldyBWaWV3KCRjb250cm9sbGVyT2JqLCRwYXRoKTsJCSAgICAKCgkJCQkgICAgCQkJCQoJCQkJICAgIAkJCX0KCQkJCSAgICAJCQllbHNlCgkJCQkgICAgCQkJewoJCQkJCQkgICAgCQkvKiRlcnJvck9iaj0gbmV3IEV4Y2VwdGlvbnMoIjEwMDQiLCRpbmZvKTsKCQkJCSAgICAJCQkJcmV0dXJuICRlcnJvck9iai0+dGhyb3dFeGNlcHRpb24oKTsvLyBtaXNzaW5nIHZpZXcqLwoJCQkJICAgIAkJCQl0cmlnZ2VyX2Vycm9yKCJNSVNTSU5HX1ZJRVdfRklMRSIsRV9VU0VSX0VSUk9SKTsgLy8gbWlzc2luZyB2aWV3CgkJCQkgICAgCQkJfQoJCQkJICAgIAkJfQoJCQkJICAgIAkJZWxzZQoJCQkJICAgIAkJewoJCQkJICAgIAkJCS8vIEl0cyBhIGFqYXggY2FsbCBzbzogCgkJCQkgICAgCQkJLyoKCQkJCQkJCQkxKSBUaXRsZSBzZXQgcHJvcGVydHkgd2lsbCBub3Qgd29yayBhcyBub3QgcmVxdWlyZWQuCgkJCQkJCQkJMikgUGFyYW1ldGVycyB0byB2aWV3IGFyZSBub3QgYWxsb3dlZC4KCQkJCSAgICAJCQkqLwoJCQkJCQkJCQoJCQkJCQkJCSR2aWV3ID0gJGNvbnRyb2xsZXJPYmotPnZpZXc7CgkJCQkJCQkJaWYoY291bnQoJHZpZXcpPjApCgkJCQkJCQkJewoJCQkJCQkJCQl0cmlnZ2VyX2Vycm9yKCJJTlZBTElEX1ZJRVdfUEFSQU1TIixFX1VTRVJfRVJST1IpOyAKCQkJCQkJCQl9CgoJCQkJICAgIAkJfQoJCQkgICAgCQl9CgkJCSAgICAJCQoJCQkgICAgCX0KCQkJICAgIAllbHNlCgkJCSAgICAJewoJCQkgICAgCQl0cmlnZ2VyX2Vycm9yKCJDT05UUk9MTEVSX0NMQVNTX0VYQ0VQVElPTiIsRV9VU0VSX0VSUk9SKTsgLy8gQ29udHJvbGxlciBDbGFzcyBub3QgZm91bmQKCQkJICAgIAl9CgkJCQl9CQoJCQkJZWxzZQoJCSAgICAJewoJCSAgICAJCXRyaWdnZXJfZXJyb3IoIlVOREVGSU5FRF9DT05UUk9MTEVSX0VYQ0VQVElPTiIsRV9VU0VSX0VSUk9SKTsvL3VuZGVmaW5lZCBDb250cm9sbGVyCgkJICAgIAl9CgkJCX0JCgkJCWVsc2UKCSAgICAJewoJICAgIAkJdHJpZ2dlcl9lcnJvcigiVU5ERUZJTkVEX01PRFVMRV9FWENFUFRJT04iLEVfVVNFUl9FUlJPUik7CgkgICAgCX0KCSAgICB9CgkJCgl9Cg==',
//       ),
//     ),
//   ),
//   'esh_commentmeta' => 
//   array (
//     'properties' => 
//     array (
//       0 => 'meta_id',
//       1 => 'comment_id',
//       2 => 'meta_key',
//       3 => 'meta_value',
//       4 => 'db',
//     ),
//     'methods' => 
//     array (
//       '__construct' => 
//       array (
//         'params' => 
//         array (
//         ),
//         'code' => 'IGZ1bmN0aW9uIF9fY29uc3RydWN0KCkKewogJGNsYXNzID0gX19DTEFTU19fOwpwYXJlbnQ6Ol9fY29uc3RydWN0KCdlc2hhbnRzYWh1JywkY2xhc3MpOwp9Cg==',
//       ),
//       '__get' => 
//       array (
//         'params' => 
//         array (
//           0 => 'property',
//         ),
//         'code' => 'IHB1YmxpYyBmdW5jdGlvbiBfX2dldCgkcHJvcGVydHkpIHsKICAgIGlmIChwcm9wZXJ0eV9leGlzdHMoJHRoaXMsICRwcm9wZXJ0eSkpIHsKICAgICAgcmV0dXJuICR0aGlzLT4kcHJvcGVydHk7CiAgICB9CiAgfQo=',
//       ),
//       '__set' => 
//       array (
//         'params' => 
//         array (
//           0 => 'property',
//           1 => 'value',
//         ),
//         'code' => 'ICBwdWJsaWMgZnVuY3Rpb24gX19zZXQoJHByb3BlcnR5LCAkdmFsdWUpIHsKICAgIGlmIChwcm9wZXJ0eV9leGlzdHMoJHRoaXMsICRwcm9wZXJ0eSkpIHsKICAgICAgJHRoaXMtPiRwcm9wZXJ0eSA9ICR2YWx1ZTsKICAgIH0KICAgIHJldHVybiAkdGhpczsKICB9Cg==',
//       ),
//     ),
//   ),
//   'esh_comments' => 
//   array (
//     'properties' => 
//     array (
//       0 => 'comment_content',
//       1 => 'comment_karma',
//       2 => 'comment_approved',
//       3 => 'comment_agent',
//       4 => 'comment_type',
//       5 => 'comment_parent',
//       6 => 'comment_date_gmt',
//       7 => 'comment_date',
//       8 => 'comment_author_IP',
//       9 => 'comment_author_url',
//       10 => 'comment_author_email',
//       11 => 'comment_author',
//       12 => 'comment_post_ID',
//       13 => 'comment_ID',
//       14 => 'user_id',
//       15 => 'db',
//     ),
//     'methods' => 
//     array (
//       '__construct' => 
//       array (
//         'params' => 
//         array (
//         ),
//         'code' => 'IGZ1bmN0aW9uIF9fY29uc3RydWN0KCkKewogJGNsYXNzID0gX19DTEFTU19fOwpwYXJlbnQ6Ol9fY29uc3RydWN0KCdlc2hhbnRzYWh1JywkY2xhc3MpOwp9Cg==',
//       ),
//       '__get' => 
//       array (
//         'params' => 
//         array (
//           0 => 'property',
//         ),
//         'code' => 'IHB1YmxpYyBmdW5jdGlvbiBfX2dldCgkcHJvcGVydHkpIHsKICAgIGlmIChwcm9wZXJ0eV9leGlzdHMoJHRoaXMsICRwcm9wZXJ0eSkpIHsKICAgICAgcmV0dXJuICR0aGlzLT4kcHJvcGVydHk7CiAgICB9CiAgfQo=',
//       ),
//       '__set' => 
//       array (
//         'params' => 
//         array (
//           0 => 'property',
//           1 => 'value',
//         ),
//         'code' => 'ICBwdWJsaWMgZnVuY3Rpb24gX19zZXQoJHByb3BlcnR5LCAkdmFsdWUpIHsKICAgIGlmIChwcm9wZXJ0eV9leGlzdHMoJHRoaXMsICRwcm9wZXJ0eSkpIHsKICAgICAgJHRoaXMtPiRwcm9wZXJ0eSA9ICR2YWx1ZTsKICAgIH0KICAgIHJldHVybiAkdGhpczsKICB9Cg==',
//       ),
//     ),
//   ),
//   'hcv' => 
//   array (
//     'properties' => 
//     array (
//       0 => 'email',
//       1 => 'puny',
//       2 => 'db',
//     ),
//     'methods' => 
//     array (
//       '__construct' => 
//       array (
//         'params' => 
//         array (
//         ),
//         'code' => 'IGZ1bmN0aW9uIF9fY29uc3RydWN0KCkKewogJGNsYXNzID0gX19DTEFTU19fOwpwYXJlbnQ6Ol9fY29uc3RydWN0KCdmb3JrYWRtaW4nLCRjbGFzcyk7Cn0K',
//       ),
//       '__get' => 
//       array (
//         'params' => 
//         array (
//           0 => 'property',
//         ),
//         'code' => 'IHB1YmxpYyBmdW5jdGlvbiBfX2dldCgkcHJvcGVydHkpIHsKICAgIGlmIChwcm9wZXJ0eV9leGlzdHMoJHRoaXMsICRwcm9wZXJ0eSkpIHsKICAgICAgcmV0dXJuICR0aGlzLT4kcHJvcGVydHk7CiAgICB9CiAgfQo=',
//       ),
//       '__set' => 
//       array (
//         'params' => 
//         array (
//           0 => 'property',
//           1 => 'value',
//         ),
//         'code' => 'ICBwdWJsaWMgZnVuY3Rpb24gX19zZXQoJHByb3BlcnR5LCAkdmFsdWUpIHsKICAgIGlmIChwcm9wZXJ0eV9leGlzdHMoJHRoaXMsICRwcm9wZXJ0eSkpIHsKICAgICAgJHRoaXMtPiRwcm9wZXJ0eSA9ICR2YWx1ZTsKICAgIH0KICAgIHJldHVybiAkdGhpczsKICB9Cg==',
//       ),
//     ),
//   ),
//   'users' => 
//   array (
//     'properties' => 
//     array (
//       0 => 'role',
//       1 => 'password',
//       2 => 'username',
//       3 => 'id',
//       4 => 'token',
//       5 => 'cdate',
//       6 => 'db',
//     ),
//     'methods' => 
//     array (
//       '__construct' => 
//       array (
//         'params' => 
//         array (
//         ),
//         'code' => 'IGZ1bmN0aW9uIF9fY29uc3RydWN0KCkKewogJGNsYXNzID0gX19DTEFTU19fOwpwYXJlbnQ6Ol9fY29uc3RydWN0KCdmb3JrYWRtaW4nLCRjbGFzcyk7Cn0K',
//       ),
//       '__get' => 
//       array (
//         'params' => 
//         array (
//           0 => 'property',
//         ),
//         'code' => 'IHB1YmxpYyBmdW5jdGlvbiBfX2dldCgkcHJvcGVydHkpIHsKICAgIGlmIChwcm9wZXJ0eV9leGlzdHMoJHRoaXMsICRwcm9wZXJ0eSkpIHsKICAgICAgcmV0dXJuICR0aGlzLT4kcHJvcGVydHk7CiAgICB9CiAgfQo=',
//       ),
//       '__set' => 
//       array (
//         'params' => 
//         array (
//           0 => 'property',
//           1 => 'value',
//         ),
//         'code' => 'ICBwdWJsaWMgZnVuY3Rpb24gX19zZXQoJHByb3BlcnR5LCAkdmFsdWUpIHsKICAgIGlmIChwcm9wZXJ0eV9leGlzdHMoJHRoaXMsICRwcm9wZXJ0eSkpIHsKICAgICAgJHRoaXMtPiRwcm9wZXJ0eSA9ICR2YWx1ZTsKICAgIH0KICAgIHJldHVybiAkdGhpczsKICB9Cg==',
//       ),
//     ),
//   ),
//   'user_profile' => 
//   array (
//     'properties' => 
//     array (
//       0 => 'user_id',
//       1 => 'name',
//       2 => 'id',
//       3 => 'img_url',
//       4 => 'first_name',
//       5 => 'last_name',
//       6 => 'db',
//     ),
//     'methods' => 
//     array (
//       '__construct' => 
//       array (
//         'params' => 
//         array (
//         ),
//         'code' => 'IGZ1bmN0aW9uIF9fY29uc3RydWN0KCkKewogJGNsYXNzID0gX19DTEFTU19fOwpwYXJlbnQ6Ol9fY29uc3RydWN0KCdmb3JrYWRtaW4nLCRjbGFzcyk7Cn0K',
//       ),
//       '__get' => 
//       array (
//         'params' => 
//         array (
//           0 => 'property',
//         ),
//         'code' => 'IHB1YmxpYyBmdW5jdGlvbiBfX2dldCgkcHJvcGVydHkpIHsKICAgIGlmIChwcm9wZXJ0eV9leGlzdHMoJHRoaXMsICRwcm9wZXJ0eSkpIHsKICAgICAgcmV0dXJuICR0aGlzLT4kcHJvcGVydHk7CiAgICB9CiAgfQo=',
//       ),
//       '__set' => 
//       array (
//         'params' => 
//         array (
//           0 => 'property',
//           1 => 'value',
//         ),
//         'code' => 'ICBwdWJsaWMgZnVuY3Rpb24gX19zZXQoJHByb3BlcnR5LCAkdmFsdWUpIHsKICAgIGlmIChwcm9wZXJ0eV9leGlzdHMoJHRoaXMsICRwcm9wZXJ0eSkpIHsKICAgICAgJHRoaXMtPiRwcm9wZXJ0eSA9ICR2YWx1ZTsKICAgIH0KICAgIHJldHVybiAkdGhpczsKICB9Cg==',
//       ),
//     ),
//   ),
//   'collations' => 
//   array (
//     'properties' => 
//     array (
//       0 => 'COLLATION_NAME',
//       1 => 'CHARACTER_SET_NAME',
//       2 => 'ID',
//       3 => 'IS_DEFAULT',
//       4 => 'IS_COMPILED',
//       5 => 'SORTLEN',
//       6 => 'db',
//     ),
//     'methods' => 
//     array (
//       '__construct' => 
//       array (
//         'params' => 
//         array (
//         ),
//         'code' => 'IGZ1bmN0aW9uIF9fY29uc3RydWN0KCkKewogJGNsYXNzID0gX19DTEFTU19fOwpwYXJlbnQ6Ol9fY29uc3RydWN0KCdpbmZvcm1hdGlvbl9zY2hlbWEnLCRjbGFzcyk7Cn0K',
//       ),
//       '__get' => 
//       array (
//         'params' => 
//         array (
//           0 => 'property',
//         ),
//         'code' => 'IHB1YmxpYyBmdW5jdGlvbiBfX2dldCgkcHJvcGVydHkpIHsKICAgIGlmIChwcm9wZXJ0eV9leGlzdHMoJHRoaXMsICRwcm9wZXJ0eSkpIHsKICAgICAgcmV0dXJuICR0aGlzLT4kcHJvcGVydHk7CiAgICB9CiAgfQo=',
//       ),
//       '__set' => 
//       array (
//         'params' => 
//         array (
//           0 => 'property',
//           1 => 'value',
//         ),
//         'code' => 'ICBwdWJsaWMgZnVuY3Rpb24gX19zZXQoJHByb3BlcnR5LCAkdmFsdWUpIHsKICAgIGlmIChwcm9wZXJ0eV9leGlzdHMoJHRoaXMsICRwcm9wZXJ0eSkpIHsKICAgICAgJHRoaXMtPiRwcm9wZXJ0eSA9ICR2YWx1ZTsKICAgIH0KICAgIHJldHVybiAkdGhpczsKICB9Cg==',
//       ),
//     ),
//   ),
//   'nav_links' => 
//   array (
//     'properties' => 
//     array (
//       0 => 'id',
//       1 => 'text',
//       2 => 'url',
//       3 => 'bold_text',
//       4 => 'db',
//     ),
//     'methods' => 
//     array (
//       '__construct' => 
//       array (
//         'params' => 
//         array (
//         ),
//         'code' => 'CWZ1bmN0aW9uIF9fY29uc3RydWN0KCkKCXsKCQkkY2xhc3MgPSBfX0NMQVNTX187CgkJcGFyZW50OjpfX2NvbnN0cnVjdCgibWFpbmRiIiwkY2xhc3MpOwoJfQo=',
//       ),
//       '__get' => 
//       array (
//         'params' => 
//         array (
//           0 => 'property',
//         ),
//         'code' => 'ICBwdWJsaWMgZnVuY3Rpb24gX19nZXQoJHByb3BlcnR5KSB7CiAgICBpZiAocHJvcGVydHlfZXhpc3RzKCR0aGlzLCAkcHJvcGVydHkpKSB7CiAgICAgIHJldHVybiAkdGhpcy0+JHByb3BlcnR5OwogICAgfQogIH0K',
//       ),
//       '__set' => 
//       array (
//         'params' => 
//         array (
//           0 => 'property',
//           1 => 'value',
//         ),
//         'code' => 'ICBwdWJsaWMgZnVuY3Rpb24gX19zZXQoJHByb3BlcnR5LCAkdmFsdWUpIHsKICAgIGlmIChwcm9wZXJ0eV9leGlzdHMoJHRoaXMsICRwcm9wZXJ0eSkpIHsKICAgICAgJHRoaXMtPiRwcm9wZXJ0eSA9ICR2YWx1ZTsKICAgIH0KCiAgICByZXR1cm4gJHRoaXM7CiAgfQo=',
//       ),
//     ),
//   ),
//   'webservice' => 
//   array (
//     'properties' => 
//     array (
//     ),
//     'methods' => 
//     array (
//       '__construct' => 
//       array (
//         'params' => 
//         array (
//         ),
//         'code' => 'CWZ1bmN0aW9uIF9fY29uc3RydWN0KCkKCXsKCQkkaG9zdD0kR0xPQkFMU1snaG9zdCddOwoJCSRjb25maWcgPSBuZXcgYXBwQ29uZmlnKCJhcHBsaWNhdGlvbiIsJGhvc3QpOwoJCSRpbmlEYXRhID0gJGNvbmZpZy0+Z2V0KCk7CgoJCSRwbHVnaW5zID0gJGluaURhdGFbInBsdWdpbnMiXTsKCQkkbW9kdWxlPSRwbHVnaW5zWyd3ZWJzZXJ2aWNlLm1vZHVsZSddOwoJCSRwYXRoID0gJF9TRVJWRVJbJ0RPQ1VNRU5UX1JPT1QnXS4iLyIuJGhvc3QuIi9tb2R1bGVzLyIuJG1vZHVsZS4iL2NvbnRyb2xsZXJzLyI7CgkJZm9yZWFjaChzY2FuZGlyKCRwYXRoKSBhcyAkY2xhc3MpCgkJewoJCQlpZiAoJy4nID09PSAkY2xhc3MpIGNvbnRpbnVlOwoJCSAgICBpZiAoJy4uJyA9PT0gJGNsYXNzKSBjb250aW51ZTsKCQkgICAgaW5jbHVkZV9vbmNlICRwYXRoLiRjbGFzczsKCQl9Cgl9Cg==',
//       ),
//       'getClasses' => 
//       array (
//         'params' => 
//         array (
//         ),
//         'code' => 'CXB1YmxpYyBmdW5jdGlvbiBnZXRDbGFzc2VzKCkKCXsKCQkkaG9zdD0kR0xPQkFMU1snaG9zdCddOwoJCSRjb25maWcgPSBuZXcgYXBwQ29uZmlnKCJhcHBsaWNhdGlvbiIsJGhvc3QpOwoJCSRpbmlEYXRhID0gJGNvbmZpZy0+Z2V0KCk7CgkJJGluaURhdGEgPSAkY29uZmlnLT5nZXQoKTsKCQkkcGx1Z2lucyA9ICRpbmlEYXRhWyJwbHVnaW5zIl07CgkJJG1vZHVsZT0kcGx1Z2luc1snd2Vic2VydmljZS5tb2R1bGUnXTsKCQkkY2xhc3Nlcz0gYXJyYXkoKTsKCQlmb3JlYWNoKGdldF9kZWNsYXJlZF9jbGFzc2VzKCkgYXMgJGNsYXNzKQoJCXsKCQkJaWYocHJlZ19tYXRjaCgiLyIuJG1vZHVsZS4iLipDb250cm9sbGVyLyIsICRjbGFzcykpCgkJCQkkY2xhc3Nlc1tdID0gJGNsYXNzOwoJCX0KCQlyZXR1cm4gJGNsYXNzZXM7Cgl9Cg==',
//       ),
//     ),
//   ),
//   'debughelper' => 
//   array (
//     'properties' => 
//     array (
//       0 => 'initialTime',
//       1 => 'initialMemory',
//     ),
//     'methods' => 
//     array (
//       '__construct' => 
//       array (
//         'params' => 
//         array (
//         ),
//         'code' => 'CWZ1bmN0aW9uIF9fY29uc3RydWN0KCkNCgl7DQoJCSR0aGlzLT5pbml0aWFsTWVtb3J5ID0gJHRoaXMtPmdldE1lbW9yeVVzZXMoKTsNCgkJJHRoaXMtPmluaXRpYWxUaW1lID0gJHRoaXMtPmdldEN1cnJlbnRUaW1lKCk7DQoJfQ0K',
//       ),
//       'getMemoryUses' => 
//       array (
//         'params' => 
//         array (
//           0 => 'decimals',
//         ),
//         'code' => 'CWZ1bmN0aW9uIGdldE1lbW9yeVVzZXMoJGRlY2ltYWxzID0gMikNCgl7DQoJICAgICRyZXN1bHQgPSAwOw0KDQoJICAgIGlmIChmdW5jdGlvbl9leGlzdHMoJ21lbW9yeV9nZXRfdXNhZ2UnKSkNCgkgICAgew0KCSAgICAgICAgJHJlc3VsdCA9IG1lbW9yeV9nZXRfdXNhZ2UoKSAvIDEwMjQ7DQoJICAgIH0NCg0KCSAgICBlbHNlDQoJICAgIHsNCgkgICAgICAgIGlmIChmdW5jdGlvbl9leGlzdHMoJ2V4ZWMnKSkNCgkgICAgICAgIHsNCgkgICAgICAgICAgICAkb3V0cHV0ID0gYXJyYXkoKTsNCg0KCSAgICAgICAgICAgIGlmIChzdWJzdHIoc3RydG91cHBlcihQSFBfT1MpLCAwLCAzKSA9PSAnV0lOJykNCgkgICAgICAgICAgICB7DQoJICAgICAgICAgICAgICAgIGV4ZWMoJ3Rhc2tsaXN0IC9GSSAiUElEIGVxICcgLiBnZXRteXBpZCgpIC4gJyIgL0ZPIExJU1QnLCAkb3V0cHV0KTsNCg0KCSAgICAgICAgICAgICAgICAkcmVzdWx0ID0gcHJlZ19yZXBsYWNlKCcvW1xEXS8nLCAnJywgJG91dHB1dFs1XSk7DQoJICAgICAgICAgICAgfQ0KDQoJICAgICAgICAgICAgZWxzZQ0KCSAgICAgICAgICAgIHsNCgkgICAgICAgICAgICAgICAgZXhlYygncHMgLWVvJW1lbSxyc3MscGlkIHwgZ3JlcCAnIC4gZ2V0bXlwaWQoKSwgJG91dHB1dCk7DQoNCgkgICAgICAgICAgICAgICAgJG91dHB1dCA9IGV4cGxvZGUoJyAgJywgJG91dHB1dFswXSk7DQoNCgkgICAgICAgICAgICAgICAgJHJlc3VsdCA9ICRvdXRwdXRbMV07DQoJICAgICAgICAgICAgfQ0KCSAgICAgICAgfQ0KCSAgICB9DQoJICAgIHJldHVybiAkcmVzdWx0Ow0KCX0NCg==',
//       ),
//       'getCurrentTime' => 
//       array (
//         'params' => 
//         array (
//         ),
//         'code' => 'CWZ1bmN0aW9uIGdldEN1cnJlbnRUaW1lKCkNCgl7DQoJCSRtdGltZSA9IG1pY3JvdGltZSgpOw0KCSAgICAkbXRpbWUgPSBleHBsb2RlKCIgIiwkbXRpbWUpOw0KCSAgICAkbXRpbWUgPSAkbXRpbWVbMV0gKyAkbXRpbWVbMF07DQoJICAgIHJldHVybiAkbXRpbWU7DQoJfQ0K',
//       ),
//     ),
//   ),
//   'defaulthelper' => 
//   array (
//     'properties' => 
//     array (
//     ),
//     'methods' => 
//     array (
//       '__construct' => 
//       array (
//         'params' => 
//         array (
//         ),
//         'code' => 'CWZ1bmN0aW9uIF9fY29uc3RydWN0KCkNCgl7DQoJCQ0KCX0NCg==',
//       ),
//       'currentUser' => 
//       array (
//         'params' => 
//         array (
//         ),
//         'code' => 'CWZ1bmN0aW9uIGN1cnJlbnRVc2VyKCkNCgl7DQoJCXJldHVybiAkX1NFU1NJT05bJ3VzZXInXTsNCgl9DQo=',
//       ),
//     ),
//   ),
// );

 ?>